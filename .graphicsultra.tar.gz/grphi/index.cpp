3. DDA algorithm for line drawing

#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;

int round(int x){return (int)(x+0.5);}

void dda(int xa,int ya,int xb,int yb){

int dx=xb-xa,dy=yb-ya,steps,x=xa,y=ya;
float xinc,yinc;
if(abs(dx)>abs(dy)) steps=abs(dx);
else steps=abs(dy);
xinc=dx/(float)steps;
yinc=dy/(float)steps;
putpixel(round(x),round(y),WHITE);
for(int i=0;i<steps;i++){
x+=xinc;y+=yinc;
putpixel(round(x),round(y),WHITE);
}

}

int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
dda(100,100,200,200);
delay(1000);
closegraph();
return 0;
}

4. Bresenham line drawing algorithm

#include<stdio.h>
#include<graphics.h>
int abs(int n)
{
return ((n>0)?n:((-1)*n));

}
void line_bres(int xa,int ya,int xb,int yb)
{
int dx=abs(xa-xb);
int dy=abs(ya-yb);
int p=2*dy-dx;
int twody=2*dy;
int twodydx=2*(dy-dx);
int x,y,xEnd;
if(xa>xb)
{
x=xb;
y=yb;
xEnd=xa;
}
else
{
x=xa;
y=ya;
xEnd=xb;
}
putpixel(x,y,15);
while(x<xEnd)
{
x++;
if(p<0) p=p+twody;
else
{
y++;
p=p+twodydx;
}
putpixel(x,y,15);
}
}
int main()
{
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
line_bres(0,200,50,100);
delay(1000);
closegraph();
return 0;
}

5. Mid point circle drawing

#include<stdio.h>
#include<graphics.h>
void draw(int xc,int yc,int x,int y)
{
putpixel(xc+x,yc+y,WHITE);
putpixel(xc+x,yc-y,WHITE);
putpixel(xc-x,yc+y,WHITE);
putpixel(xc-x,yc-y,WHITE);
putpixel(xc+y,yc+x,WHITE);
putpixel(xc+y,yc-x,WHITE);
putpixel(xc-y,yc+x,WHITE);
putpixel(xc-y,yc-x,WHITE);
}
void circle(int xc,int yc,int r)
{
int x=0;
int y=r;
int d=1-r;
draw(xc,yc,x,y);
while(y>=x)
{

x++;
if(d<0) d=d+2*x+1;
else
{
d=d+2*x+1-2*y;
y--;
}
draw(xc,yc,x,y);
}
}
int main()
{
int gd=DETECT,gm;
int xc=200;
int yc=200;
int r=100;
initgraph(&gd,&gm,NULL);
circle(xc,yc,r);
delay(1000);
closegraph();
return 0;
}



7. Ellipse generation algorithm

#include<stdio.h>
//#include<conio.h>
#include<graphics.h>
#include<math.h>
void disp();
float x,y;
int xc,yc;
int main()
{
                int gd=DETECT,gm,a,b;
                float p1,p2;
                //clrscr();
               
                printf("*** Ellipse Generating Algorithm ***\n");
                printf("Enter the value of Xc\t");
                scanf("%d",&xc);
                printf("Enter the value of yc\t");
                scanf("%d",&yc);
                printf("Enter X axis length\t");
                scanf("%d",&a);
                printf("Enter Y axis length\t");
                scanf("%d",&b);
                x=0;y=b;
initgraph(&gd,&gm,"c:\\turboc3\\bgi");
                disp();
                p1=(b*b)-(a*a*b)+(a*a)/4;
 
                while((2.0*b*b*x)<=(2.0*a*a*y))
                {
                                x++;
                                if(p1<=0)
                                p1=p1+(2.0*b*b*x)+(b*b);
                                else
                                {
                                                y--;
                                                p1=p1+(2.0*b*b*x)+(b*b)-(2.0*a*a*y);
                                }
                                disp();
                                x=-x;
                                disp();
                                x=-x;
                                delay(50);
                }
                x=a;
                y=0;
                disp();
                p2=(a*a)+2.0*(b*b*a)+(b*b)/4;
                while((2.0*b*b*x)>(2.0*a*a*y))
                {
                                y++;
                                if(p2>0)
                                p2=p2+(a*a)-(2.0*a*a*y);
                                else
                                {
                                                x--;
                                                p2=p2+(2.0*b*b*x)-(2.0*a*a*y)+(a*a);
                                }
                                disp();
                                y=-y;
                                disp();
                                y=-y;
                                delay(50);
                }
                getch();
                closegraph();
}
void disp()
{
                putpixel(xc+x,yc+y,7);
                putpixel(xc-x,yc+y,7);
                putpixel(xc+x,yc-y,7);
                putpixel(xc+x,yc-y,7);
}



8. 2d transformations for line triangle and square

Line

 #include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
int main()
{
            int gm;
            int gd=DETECT;
            int x1,y1,x2,y2,nx1t,ny1t,nx2t,ny2t;
            int nx1s,ny1s,nx2s,ny2s;
            int nx1r,ny1r,nx2r,ny2r;
            int sx,sy,xt,yt,r;
            float t;
            printf("\n\t Enter the points of line");
            scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
           printf("\n Enter the translation factor");
                                    scanf("%d%d",&xt,&yt);
                                    nx1t=x1+xt;
                                    ny1t=y1+yt;
                                    nx2t=x2+xt;
                                    ny2t=y2+yt;
            
                                    
 printf("\n Enter the angle of rotation");
                                    scanf("%d",&r);
                                    t=3.14*r/180;
                                    nx1r=abs(x1*cos(t)-y1*sin(t));
                                    ny1r=abs(x1*sin(t)+y1*cos(t));
                                    nx2r=abs(x2*cos(t)-y2*sin(t));
                                    ny2r=abs(x2*sin(t)+y2*cos(t));
                                    
printf("\n Enter the scaling factor");
                                    scanf("%d%d",&sx,&sy);
                                    nx1s=x1*sx;
                                    ny1s=y2*sy;
                                    nx2s=x2*sx;
                                    ny2s=y2*sy;
                                  
            initgraph(&gd,&gm,NULL);
            line(x1,y1,x2,y2);
                  line(nx1t,ny1t,nx2t,ny2t);
                                   
                                    line(nx1r,ny1r,nx2r,ny2r);
                                  line(nx1s,ny1s,nx2s,ny2s);
                                    
                                    delay(20000);
                                    closegraph();
return 0;
                                    }

 
Triangle

#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
int main()
{
            int gm;
            int gd=DETECT;
            int x1=50,x2=100,x3=75,y1=50,y2=50,y3=100,nx1t,nx2t,nx3t,ny1t,ny2t,ny3t;
            int nx1s,nx2s,nx3s,ny1s,ny2s,ny3s;
            int nx1r,nx2r,nx3r,ny1r,ny2r,ny3r;
            int sx=2,sy=2,xt=100,yt=0,r=45;
            float t;
         //   printf("\t Program for basic transactions");
           // printf("\n\t Enter the points of triangle");
         //   scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);
           // printf("\n 1.Transaction\n 2.Rotation\n 3.Scalling\n 4.exit");
            //printf("Enter your choice:");
            //scanf("%d",&c);
          // printf("\n Enter the translation factor");
                                    //scanf("%d%d",&xt,&yt);
                                    nx1t=x1+xt;
                                    ny1t=y1+yt;
                                    nx2t=x2+xt;
                                    ny2t=y2+yt;
                                    nx3t=x3+xt;
                                    ny3t=y3+yt;
                                    
 //printf("\n Enter the angle of rotation");
                                   // scanf("%d",&r);
                                    t=3.14*r/180;
                                    nx1r=abs(x1*cos(t)-y1*sin(t));
                                    ny1r=abs(x1*sin(t)+y1*cos(t));
                                    nx2r=abs(x2*cos(t)-y2*sin(t));
                                    ny2r=abs(x2*sin(t)+y2*cos(t));
                                    nx3r=abs(x3*cos(t)-y3*sin(t));
                                    ny3r=abs(x3*sin(t)+y3*cos(t));
                                    
//printf("\n Enter the scalling factor");
                                   // scanf("%d%d",&sx,&sy);
                                    nx1s=x1*sx;
                                    ny1s=y2*sy;
                                    nx2s=x2*sx;
                                    ny2s=y2*sy;
                                    nx3s=x3*sx;
                                    ny3s=y3*sy;

            initgraph(&gd,&gm,NULL);
            line(x1,y1,x2,y2);
            line(x2,y2,x3,y3);
            line(x3,y3,x1,y1);    
                                   line(nx1t,ny1t,nx2t,ny2t);
                                    line(nx2t,ny2t,nx3t,ny3t);
                                    line(nx3t,ny3t,nx1t,ny1t);

                                    line(nx1r,ny1r,nx2r,ny2r);
                                    line(nx2r,ny2r,nx3r,ny3r);
                                    line(nx3r,ny3r,nx1r,ny1r);
                             
                                    line(nx1s,ny1s,nx2s,ny2s);
                                    line(nx2s,ny2s,nx3s,ny3s);
                                    line(nx3s,ny3s,nx1s,ny1s);

                                    delay(10000);
                                    closegraph();
return 0;
                                    }

Square

 #include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
int main()
{
            int gm;
            int gd=DETECT;
            int x1=50,x2=100,x3=100,x4=50,y1=50,y2=50,y3=100,y4=100,nx1t,nx2t,nx3t,nx4t,ny1t,ny2t,ny3t,ny4t;
            int nx1s,nx2s,nx3s,nx4s,ny1s,ny2s,ny3s,ny4s;
            int nx1r,nx2r,nx3r,nx4r,ny1r,ny2r,ny3r,ny4r;
            int sx=2,sy=2,xt=100,yt=0,r=30;
            float t;
           // printf("\t Program for basic transactions");
            //printf("\n\t Enter the points of square");
           // scanf("%d%d%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3,&x4,&y4);
           // printf("\n 1.Transaction\n 2.Rotation\n 3.Scalling\n 4.exit");
            //printf("Enter your choice:");
            //scanf("%d",&c);
         // printf("\n Enter the translation factor");
                                  //  scanf("%d%d",&xt,&yt);
                                    nx1t=x1+xt;
                                    ny1t=y1+yt;
                                    nx2t=x2+xt;
                                    ny2t=y2+yt;
                                    nx3t=x3+xt;
                                    ny3t=y3+yt;
                                    nx4t=x4+xt;
                                    ny4t=y4+yt;
                                    
 //printf("\n Enter the angle of rotation");
                                   // scanf("%d",&r);
                                    t=3.14*r/180;
                                    nx1r=abs(x1*cos(t)-y1*sin(t));
                                    ny1r=abs(x1*sin(t)+y1*cos(t));
                                    nx2r=abs(x2*cos(t)-y2*sin(t));
                                    ny2r=abs(x2*sin(t)+y2*cos(t));
                                    nx3r=abs(x3*cos(t)-y3*sin(t));
                                    ny3r=abs(x3*sin(t)+y3*cos(t));
                                    nx4r=abs(x4*cos(t)-y4*sin(t));
                                    ny4r=abs(x4*sin(t)+y4*cos(t));
//printf("\n Enter the scalling factor");
                                   // scanf("%d%d",&sx,&sy);
                                    nx1s=x1*sx;
                                    ny1s=y1*sy;
                                    nx2s=x2*sx;
                                    ny2s=y2*sy;
                                    nx3s=x3*sx;
                                    ny3s=y3*sy;
                                    nx4s=x4*sx;
                                    ny4s=y4*sy;
            initgraph(&gd,&gm,NULL);
            line(x1,y1,x2,y2);
            line(x2,y2,x3,y3);
            line(x3,y3,x4,y4);
            line(x4,y4,x1,y1);    
                                   line(nx1t,ny1t,nx2t,ny2t);
                                    line(nx2t,ny2t,nx3t,ny3t);
                                    line(nx3t,ny3t,nx4t,ny4t);
                                    line(nx4t,ny4t,nx1t,ny1t);

                                    line(nx1r,ny1r,nx2r,ny2r);
                                    line(nx2r,ny2r,nx3r,ny3r);
                                    line(nx3r,ny3r,nx4r,ny4r);
                                    line(nx4r,ny4r,nx1r,ny1r);

                                   line(nx1s,ny1s,nx2s,ny2s);
                                    line(nx2s,ny2s,nx3s,ny3s);
                                    line(nx3s,ny3s,nx4s,ny4s);
                                    line(nx4s,ny4s,nx1s,ny1s);
                                    delay(10000);
                                    closegraph();
return 0;
                                    }


9. Homogeneous coordinate 2d transformation

Scaling

#include<stdio.h>
#include<graphics.h>
 
// Matrix Multiplication to find new Coordinates.
// s[][] is scaling matrix. p[][] is to store
// points that needs to be scaled.
// p[0][0] is x coordinate of point.
// p[1][0] is y coordinate of given point.
void findNewCoordinate(int s[][3], int p[][1])
{
    int temp[3][1] = { 0 };
 
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 1; j++)
            for (int k = 0; k < 3; k++)
                temp[i][j] += (s[i][k] * p[k][j]);
 
    p[0][0] = temp[0][0];
    p[1][0] = temp[1][0];
}
 
// Scaling the Polygon
void scale(int x[], int y[], int sx, int sy)
{
    // Triangle before Scaling
    line(x[0], y[0], x[1], y[1]);
    line(x[1], y[1], x[2], y[2]);
    line(x[2], y[2], x[0], y[0]);
 
    // Initializing the Scaling Matrix.
    int s[3][3] = { sx, 0,0, 0, sy,0,0,0,1 };
    int p[3][1];
 
    // Scaling the triangle
    for (int i = 0; i < 3; i++)
    {
        p[0][0] = x[i];
        p[1][0] = y[i];
        p[2][0]=1;
 
        findNewCoordinate(s, p);
 
        x[i] = p[0][0];
        y[i] = p[1][0];
    }
 
    // Triangle after Scaling
    line(x[0], y[0], x[1], y[1]);
    line(x[1], y[1], x[2], y[2]);
    line(x[2], y[2], x[0], y[0]);
}
 
// Driven Program
int main()
{
    int x[] = { 10, 20, 30 };
    int y[] = { 20, 10, 20 };
    int sx = 2, sy = 2;
 
    int gd=DETECT, gm;
    //detectgraph(&gd, &gm);
    initgraph(&gd, &gm," ");
 
    scale(x, y, sx,sy);
    getch();
 
    return 0;
}

10. Reflection and shearing

Reflection

#include<stdio.h>
#include<graphics.h>

int main(){
int n,i;
int gd=DETECT,gm;
printf("Enter n:");
scanf("%d",&n);
int points[2*n];
printf("Enter coordinates:");
for(i=0;i<2*n;i++)
 scanf("%d",&points[i]);
initgraph(&gd,&gm,NULL);
float x0=0,x1=getmaxx(),xmid=x1/2;
float y0=0,y1=getmaxy(),ymid=y1/2;
line(x0,y1/2,x1,y1/2);
line(x1/2,y0,x1/2,y1);
line(0,y1,x1,0);
for(i=0;i<2*n;i+=2)
 points[i]+=xmid;
drawpoly(n,points);
int npoints[2*n];
for(i=0;i<2*n;i++){
 if(i%2==0) npoints[i]=points[i];
 else npoints[i]=points[i]+2*(ymid-points[i]);
}
drawpoly(n,npoints);
for(i=0;i<2*n;i++){
 if(i%2!=0) npoints[i]=points[i];
 else npoints[i]=points[i]-2*(points[i]-xmid);
}
drawpoly(n,npoints);
float x,y,a,b;
for(i=0;i<2*n-1;i+=2){
a=points[i],b=points[i+1];
x=(a*x1*x1+x1*y1*y1-b*x1*y1)/(x1*x1+y1*y1);
y=(b*y1*y1+x1*x1*y1-a*x1*y1)/(x1*x1+y1*y1);
npoints[i]=2*x-a;
npoints[i+1]=2*y-b;
}
drawpoly(n,npoints);
delay(10000);
closegraph();
return 0;
}

Shearing

#include<stdio.h>
#include<graphics.h>

int main(){
int n,i;
int gd=DETECT,gm;
printf("Enter n:");
scanf("%d",&n);
int points[2*n],shx,shy;
printf("Enter coordinates:");
for(i=0;i<2*n;i++)
 scanf("%d",&points[i]);
printf("Enter SHx and Shy:");
scanf("%d%d",&shx,&shy);
initgraph(&gd,&gm,NULL);
drawpoly(n,points);
int npoints[2*n];
for(i=0;i<2*n;i++){
 if(i%2==0) npoints[i]=points[i]+shx*points[i+1];
 else npoints[i]=points[i];
}
drawpoly(n,npoints);
for(i=0;i<2*n;i++){
 if(i%2!=0) npoints[i]=points[i]+shy*points[i-1];
 else npoints[i]=points[i];
}
drawpoly(n,npoints);
delay(10000);
closegraph();
return 0;
}

12. Polygon filling
Boundary fill algorithm

#include<stdio.h>
#include<graphics.h>
void b_fill(int x,int y,int f,int b)
{
  int c;
  c=getpixel(x,y);
  if((c!=b)&&(c!=f))
  {
      putpixel(x,y,f);
      delay(10);
      b_fill(x+1,y,f,b);
      b_fill(x,y+1,f,b);
     // b_fill(x+1,y+1,f,b);
     // b_fill(x-1,y-1,f,b);
      b_fill(x-1,y,f,b);
      b_fill(x,y-1,f,b);
      //b_fill(x-1,y+1,f,b);
      //b_fill(x+1,y-1,f,b);
  }
}
//void b_fill(int,int,int,int);
void main()
{
  int gd=DETECT,gm;
  initgraph(&gd,&gm,"c:\\tc\\bgi");
  int points[]={150,150,200,150,175,200,150,150};
  drawpoly(4,points);
  rectangle(50,50,100,100);
 b_fill(175,155,4,15);
  b_fill(55,55,4,15);
  delay(1000);
  closegraph();
}

Flood Fill algorithm

#include <graphics.h>
#include <stdio.h>
void flood_fill4(int x,int y,int newColor,int oldColor)
{
int c;
c=getpixel(x,y);
if(c==oldColor)
{
setcolor(newColor);
putpixel (x,y,newColor);
delay(10);
flood_fill4(x+1,y,newColor,oldColor);
flood_fill4(x,y+1,newColor,oldColor);
flood_fill4(x-1,y,newColor,oldColor);
flood_fill4(x,y-1,newColor,oldColor);
}
}
void main()
{
int gd=DETECT,gm;
initgraph(&gd,&gm,"..\\bgi");
int points[]={320,150,420,300,250,300,320,150};
drawpoly(4,points);
rectangle(50,50,100,100);
flood_fill4(51,51,4,0); // 4(red) - newColor  0(black) - oldColor
          // x y point should be one greater than rectangle border
flood_fill4(251,299,4,0);
delay(1000);
closegraph();
} 

Scan line polygon fill

#include <iostream>
#include <graphics.h>
#include <stdlib.h>
using namespace std;

//Declaration of class point
class point
{
    public:
    int x,y;
};

class poly
{
    private:
        point p[20];
        int inter[20],x,y;
        int v,xmin,ymin,xmax,ymax;
    public:
        int c;
        void read();
        void calcs();
        void display();
        void ints(float);
        void sort(int);
};


void poly::read()
{
    int i;
    v=4;
        p[0].x=50;p[0].y=50;p[1].x=50;p[1].y=200;p[2].x=200;p[2].y=200;p[3].x=200;p[3].y=50;
        p[4].x=p[0].x;
        p[4].y=p[0].y;
        xmin=xmax=p[0].x;
        ymin=ymax=p[0].y;
}
//FUNCTION FOR FINDING
void poly::calcs()
{ //MAX,MIN
    for(int i=0;i<v;i++)
    {
        if(xmin>p[i].x)
        xmin=p[i].x;
        if(xmax<p[i].x)
        xmax=p[i].x;
        if(ymin>p[i].y)
        ymin=p[i].y;
        if(ymax<p[i].y)
        ymax=p[i].y;
    }
}
//DISPLAY FUNCTION
void poly::display()
{
    float s,s2;
s=ymin+0.01;
                delay(100);
                cleardevice();
                while(s<=ymax)
                {
                    ints(s);
                    sort(s);
                    s++;
                }
}

void poly::ints(float z) //DEFINE FUNCTION INTS
{
    int x1,x2,y1,y2,temp;
    c=0;
    for(int i=0;i<v;i++)
    {
        x1=p[i].x;
        y1=p[i].y;
        x2=p[i+1].x;
        y2=p[i+1].y;
        if(y2<y1)
        {
            temp=x1;
            x1=x2;
            x2=temp;
            temp=y1;
            y1=y2;
            y2=temp;
        }
        if(z<=y2&&z>=y1)
        {
            if((y1-y2)==0)
            x=x1;
            else // used to make changes in x. so that we can fill our polygon after cerain distance
            {
                x=((x2-x1)*(z-y1))/(y2-y1);
                x=x+x1;
            }
            if(x<=xmax && x>=xmin)
            inter[c++]=x;
        }
    }
}

void poly::sort(int z) //SORT FUNCTION
{
    int temp,j,i;

        for(i=0;i<v;i++)
        {
            line(p[i].x,p[i].y,p[i+1].x,p[i+1].y); // used to make hollow outlines of a polygon
        }
        delay(100);
        for(i=0; i<c;i+=2)
        {
            delay(100);
            line(inter[i],z,inter[i+1],z);  // Used to fill the polygon ....
        }
}

int main() //START OF MAIN
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
    poly x;
    x.read();
    x.calcs();
    cleardevice();
    setcolor(15);
    x.display();
    closegraph(); //CLOSE OF GRAPH
    getch();
    return 0;
}


13. Clipping

Liang Barsky Line Clipping

#include<stdio.h>
#include<graphics.h>
#include<math.h>
//#include<dos.h>
 
int main()
{
    int i,gd=DETECT,gm;
    int x1,y1,x2,y2,xmin,xmax,ymin,ymax,xx1,xx2,yy1,yy2,dx,dy;
    float t1,t2,p[4],q[4],temp;
   
    x1=120;
    y1=50;
    x2=300;
    y2=300;
   
    xmin=100;
    ymin=100;
    xmax=250;
    ymax=250;
   
    initgraph(&gd,&gm,"c:\\turboc3\\bgi");
    rectangle(xmin,ymin,xmax,ymax);
    line(x1,y1,x2,y2);
    delay(1000);
    cleardevice();
rectangle(xmin,ymin,xmax,ymax);
    dx=x2-x1;
    dy=y2-y1;
   
    p[0]=-dx;
    p[1]=dx;
    p[2]=-dy;
    p[3]=dy;
   
    q[0]=x1-xmin;
    q[1]=xmax-x1;
    q[2]=y1-ymin;
    q[3]=ymax-y1;
   
    for(i=0;i<4;i++)
    {
        if(p[i]==0)
        {
            printf("line is parallel to one of the clipping boundary");
            if(q[i]>=0)
            {
                if(i<2)
                {
                    if(y1<ymin)
                    {
                        y1=ymin;
                    }
               
                    if(y2>ymax)
                    {
                        y2=ymax;
                    }
               
                    line(x1,y1,x2,y2);
                }
               
                if(i>1)
                {
                    if(x1<xmin)
                    {
                        x1=xmin;
                    }
                   
                    if(x2>xmax)
                    {
                        x2=xmax;
                    }
                   
                    line(x1,y1,x2,y2);
                }
            }
        }
    }
   
    t1=0;
    t2=1;
   
    for(i=0;i<4;i++)
    {
        temp=q[i]/p[i];
       
        if(p[i]<0)
        {
            if(t1<=temp)
                t1=temp;
        }
        else
        {
            if(t2>temp)
                t2=temp;
        }
    }
   
    if(t1<t2)
    {
        xx1 = x1 + t1 * p[1];
        xx2 = x1 + t2 * p[1];
        yy1 = y1 + t1 * p[3];
        yy2 = y1 + t2 * p[3];
        line(xx1,yy1,xx2,yy2);
    }
   
    delay(5000);
    closegraph();
}


C++ program to implement Cohen Sutherland algorithm for line clipping.

#include <iostream>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<graphics.h>
using namespace std;
 
// Defining region codes
const int INSIDE = 0; // 0000
const int LEFT = 1;   // 0001
const int RIGHT = 2;  // 0010
const int BOTTOM = 4; // 0100
const int TOP = 8;    // 1000
 
// Defining x_max, y_max and x_min, y_min for
// clipping rectangle. Since diagonal points are
// enough to define a rectangle
const int x_max = 100;
const int y_max = 80;
const int x_min = 40;
const int y_min = 40;
 
// Function to compute region code for a point(x, y)
int computeCode(double x, double y)
{
    // initialized as being inside 
    int code = INSIDE;
 
    if (x < x_min)       // to the left of rectangle
        code |= LEFT;
    else if (x > x_max)  // to the right of rectangle
        code |= RIGHT;
    if (y < y_min)       // below the rectangle
        code |= BOTTOM;
    else if (y > y_max)  // above the rectangle
        code |= TOP;
 
    return code;
}
 
// Implementing Cohen-Sutherland algorithm
// Clipping a line from P1 = (x2, y2) to P2 = (x2, y2)
void cohenSutherlandClip(double x1, double y1,
                         double x2, double y2)
{
    // Compute region codes for P1, P2
    int code1 = computeCode(x1, y1);
    int code2 = computeCode(x2, y2);
 
    // Initialize line as outside the rectangular window
    bool accept = false;
 
    while (true)
    {
        if ((code1 == 0) && (code2 == 0))
        {
            // If both endpoints lie within rectangle
            accept = true;
            break;
        }
        else if (code1 & code2)
        {
            // If both endpoints are outside rectangle,
            // in same region
            break;
        }
        else
        {
            // Some segment of line lies within the
            // rectangle
            int code_out;
            double x, y;
 
            // At least one endpoint is outside the 
            // rectangle, pick it.
            if (code1 != 0)
                code_out = code1;
            else
                code_out = code2;
 
            // Find intersection point;
            // using formulas y = y1 + slope * (x - x1),
            // x = x1 + (1 / slope) * (y - y1)
            if (code_out & TOP)
            {
                // point is above the clip rectangle
                x = x1 + (x2 - x1) * (y_max - y1) / (y2 - y1);
                y = y_max;
            }
            else if (code_out & BOTTOM)
            {
                // point is below the rectangle
                x = x1 + (x2 - x1) * (y_min - y1) / (y2 - y1);
                y = y_min;
            }
            else if (code_out & RIGHT)
            {
                // point is to the right of rectangle
                y = y1 + (y2 - y1) * (x_max - x1) / (x2 - x1);
                x = x_max;
            }
            else if (code_out & LEFT)
            {
                // point is to the left of rectangle
                y = y1 + (y2 - y1) * (x_min - x1) / (x2 - x1);
                x = x_min;
            }
 
            // Now intersection point x,y is found
            // We replace point outside rectangle
            // by intersection point
            if (code_out == code1)
            {
                x1 = x;
                y1 = y;
                code1 = computeCode(x1, y1);
            }
            else
            {
                x2 = x;
                y2 = y;
                code2 = computeCode(x2, y2);
            }
        }
    }
    if (accept)
    {
       // cout <<"Line accepted from " << x1 << ", "
         //    << y1 << " to "<< x2 << ", " << y2 << endl;
	line(x1,y1,x2,y2);
        // Here the user can add code to display the rectangle
        // along with the accepted (portion of) lines
    }
    //else
      //  cout << "Line rejected" << endl;
}
 
// Driver code
int main()
{
    // First Line segment
    // P11 = (5, 5), P12 = (7, 7)
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
	line(10,50,40,10);
line(70,90,110,40);
line(50,50,70,70);
rectangle(40,40,100,80);
	delay(7000);
	cleardevice();
	rectangle(40,40,100,80);
    cohenSutherlandClip(50, 50, 70, 70);
    // Second Line segment
    // P21 = (7, 9), P22 = (11, 4)
    cohenSutherlandClip(70, 90, 110, 40);
 	
    // Third Line segment
    // P31 = (1, 5), P32 = (4, 1)
    cohenSutherlandClip(10, 50, 40, 10);
    sleep(10);
	closegraph();
    return 0;
}

Sutherland Hodgeman Polygon clipping

#include <stdio.h>
#include <graphics.h>
//#include <conio.h>
#include <math.h>
//#include <process.h>
#define TRUE 1
#define FALSE 0
typedef unsigned int oc;
oc Comp_oc(float x,float y);
enum  {  TOP = 0x1,
BOTTOM = 0x2,
RIGHT = 0x4,
LEFT = 0x8
};
float xmin,xmax,ymin,ymax;
void clip(float x0,float y0,float x1,float y1)
{
oc oc0,oc1,ocOut;
int accept = FALSE,done = FALSE;
oc0 = Comp_oc(x0,y0);
oc1 = Comp_oc(x1,y1);
do
{
    if(!(oc0|oc1))
    {
        accept = TRUE;
        done = TRUE;
    }
    else
    if(oc0 & oc1)
        done = TRUE;
    else
    {
        float x,y;
        ocOut = oc0?oc0:oc1;
        if(ocOut & TOP)
        {
            x = x0+(x1-x0)*(ymax-y0)/(y1-y0);
            y = ymax;
        }
        else if(ocOut & BOTTOM)
        {
            x = x0+(x1-x0)*(ymin-y0)/(y1-y0);
            y = ymin;
        }
        else if(ocOut & RIGHT)
        {
            y = y0+(y1-y0)*(xmax-x0)/(x1-x0);
            x = xmax;
        }
        else
        {
            y = y0+(y1-y0)*(xmin-x0)/(x1-x0);
            x = xmin;
        }
        if(ocOut==oc0)
        {
            x0 = x;
            y0 = y;
            oc0 = Comp_oc(x0,y0);
        }
        else
        {
            x1 = x;
            y1 = y;
            oc1 = Comp_oc(x1,y1);
          }
    }
}while(done==FALSE);
if(accept)
    line(x0,y0,x1,y1);
outtextxy(150,20,"POLYGON AFTER CLIPPING");
rectangle(xmin,ymin,xmax,ymax);
}
oc Comp_oc(float x,float y)
{
    oc code = 0;
    if(y>ymax)
        code|=TOP;
    else if(y<ymin)
            code|=BOTTOM;
    if(x>xmax)
        code|=RIGHT;
    else if(x<xmin)
        code|=LEFT;
    return code;
}
int main( )
{
float x1,y1,x2,y2;
/* request auto detection */
int gdriver = DETECT, gmode, n,poly[14],i;
//clrscr( );
printf("Enter the no of sides of polygon:");
scanf("%d",&n);
printf("\nEnter the coordinates of polygon\n");
for(i=0;i<2*n;i++)
{
    scanf("%d",&poly[i]);
}
poly[2*n]=poly[0];
poly[2*n+1]=poly[1];
printf("Enter the rectangular coordinates of clipping window\n");
scanf("%f%f%f%f",&xmin,&ymin,&xmax,&ymax);
/* initialize graphics and local variables */
initgraph(&gdriver, &gmode, "c:\\tc\\bgi");

outtextxy(150,20,"POLYGON BEFORE CLIPPING");
drawpoly(n+1,poly);
rectangle(xmin,ymin,xmax,ymax);
//getch( );
delay(5000);
cleardevice( );
for(i=0;i<n;i++)
clip(poly[2*i],poly[(2*i)+1],poly[(2*i)+2],poly[(2*i)+3]);
//getch( );
sleep(10);
restorecrtmode( );
return 0;
}

14.Perspective projection for cuboid

#include<stdio.h>
#include<math.h>
#include<graphics.h>

main()
{

int x1,y1,x2,y2,gd,gm;
int ymax,a[4][8];
float par[4][4],b[4][8];
int i,j,k,m,n,p;
int xp, yp, zp, x, y, z;


a[0][0] = 100; a[1][0] = 100; a[2][0] = -100;
a[0][1] = 200; a[1][1] = 100; a[2][1] = -100;

a[0][2] = 200; a[1][2] = 200; a[2][2] = -100;
a[0][3] = 100; a[1][3] = 200; a[2][3] = -100;

a[0][4] = 100; a[1][4] = 100; a[2][4] = -200;
a[0][5] = 200; a[1][5] = 100; a[2][5] = -200;

a[0][6] = 200; a[1][6] = 200; a[2][6] = -200;
a[0][7] = 100; a[1][7] = 200; a[2][7] = -200;


detectgraph(&gd,&gm);
initgraph(&gd,&gm, "c:\\tc\\bgi");

ymax = getmaxy();
xp = 300; yp = 320; zp = 100;

for(j=0; j<8; j++)
{
x = a[0][j]; y = a[1][j]; z = a[2][j];

b[0][j] = xp - ( (float)( x - xp )/(z - zp)) * (zp);
b[1][j] = yp - ( (float)( y - yp )/(z - zp)) * (zp);
}

/*- front plane display -*/

for(j=0;j<3;j++)
{
x1=(int) b[0][j]; y1=(int) b[1][j];
x2=(int) b[0][j+1]; y2=(int) b[1][j+1];
line( x1,ymax-y1,x2,ymax-y2);

}
x1=(int) b[0][3]; y1=(int) b[1][3];
x2=(int) b[0][0]; y2=(int) b[1][0];
line( x1, ymax-y1, x2, ymax-y2);

/*- back plane display -*/
setcolor(11);
for(j=4;j<7;j++)
{
x1=(int) b[0][j]; y1=(int) b[1][j];
x2=(int) b[0][j+1]; y2=(int) b[1][j+1];
line( x1, ymax-y1, x2, ymax-y2);

}
x1=(int) b[0][7]; y1=(int) b[1][7];
x2=(int) b[0][4]; y2=(int) b[1][4];
line( x1, ymax-y1, x2, ymax-y2);

setcolor(7);
for(i=0;i<4;i++)
{
x1=(int) b[0][i]; y1=(int) b[1][i];
x2=(int) b[0][4+i]; y2=(int) b[1][4+i];
line( x1, ymax-y1, x2, ymax-y2);
}


getch(); getch();

}

15.Perspective projection for triangle and square

#include<stdio.h>
#include<math.h>
#include<graphics.h>

int main()
{

int x1,y1,x2,y2,gd,gm;
int ymax,a[4][8];
float par[4][4],b[4][8];
int i,j,k,m,n,p;
int xp, yp, zp, x, y, z;


int choice ;

printf("Enter 3 : for triangular object.. 4: for square object \n");
scanf("%d",&choice);
if(choice ==3){
a[0][0] = 100; a[1][0] = 100; a[2][0] = -100;
a[0][1] = 200; a[1][1] = 100; a[2][1] = -100;

a[0][2] = 200; a[1][2] = 200; a[2][2] = -100;
a[0][3] = a[0][0]; a[1][3] = a[1][0]; a[2][3] = a[2][0];

a[0][4] = 100; a[1][4] = 100; a[2][4] = -200;
a[0][5] = 200; a[1][5] = 100; a[2][5] = -200;

a[0][6] = 200; a[1][6] = 200; a[2][6] = -200;
a[0][7] = a[0][4]; a[1][7] = a[1][4]; a[2][7] = a[2][4];

}

else if (choice ==4){
a[0][0] = 100; a[1][0] = 100; a[2][0] = -100;
a[0][1] = 200; a[1][1] = 100; a[2][1] = -100;

a[0][2] = 200; a[1][2] = 200; a[2][2] = -100;
a[0][3] = 100; a[1][3] = 200; a[2][3] = -100;

a[0][4] = 100; a[1][4] = 100; a[2][4] = -200;
a[0][5] = 200; a[1][5] = 100; a[2][5] = -200;

a[0][6] = 200; a[1][6] = 200; a[2][6] = -200;
a[0][7] = 100; a[1][7] = 200; a[2][7] = -200;

}
else
{
printf("invalid choice");
return 0;
}
detectgraph(&gd,&gm);
initgraph(&gd,&gm, " ");
setbkcolor(WHITE);
ymax = getmaxy();
xp = 300; yp = 320; zp = 100;

for(j=0; j<8; j++)
{
x = a[0][j]; y = a[1][j]; z = a[2][j];

b[0][j] = xp - ( (float)( x - xp )/(z - zp)) * (zp);
b[1][j] = yp - ( (float)( y - yp )/(z - zp)) * (zp);
}

/*- front plane display -*/
setcolor(BLACK);

for(j=0;j<3;j++)
{
x1=(int) b[0][j]; y1=(int) b[1][j];
x2=(int) b[0][j+1]; y2=(int) b[1][j+1];
line( x1,ymax-y1,x2,ymax-y2);

}
x1=(int) b[0][3]; y1=(int) b[1][3];
x2=(int) b[0][0]; y2=(int) b[1][0];
line( x1, ymax-y1, x2, ymax-y2);

/*- back plane display -*/
setcolor(BLACK);
for(j=4;j<7;j++)
{
x1=(int) b[0][j]; y1=(int) b[1][j];
x2=(int) b[0][j+1]; y2=(int) b[1][j+1];
line( x1, ymax-y1, x2, ymax-y2);

}
x1=(int) b[0][7]; y1=(int) b[1][7];
x2=(int) b[0][4]; y2=(int) b[1][4];
line( x1, ymax-y1, x2, ymax-y2);

setcolor(BLACK);
for(i=0;i<4;i++)
{
x1=(int) b[0][i]; y1=(int) b[1][i];
x2=(int) b[0][4+i]; y2=(int) b[1][4+i];
line( x1, ymax-y1, x2, ymax-y2);
}


getch();
return 0;
}


16. circle animation

//Circle animation

#include<stdio.h>
#include<graphics.h>
int main()
{
int gd=DETECT,gm,i;
initgraph(&gd,&gm," ");
//for moving circle from left to right,the following loop works
for(i=50;i<=getmaxx();i++)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(50+i,50,50);
floodfill(52+i,52,3);
delay(20);
cleardevice();
}
//for moving circle from right to left, the following loop works
for(i=getmaxy();i>=0;i--)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(i,50,50);
floodfill(i+2,52,3);
delay(20);
cleardevice();
}
//for moving circle from top to bottom,the following loop works
for(i=50;i<=getmaxy();i++)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(50,i,50);
floodfill(52,i+2,3);
delay(20);
cleardevice();
}
//for moving circle from bottom to top,the following loop works
for(i=getmaxy();i>=0;i--)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(50,i,50);
floodfill(52,i+2,3);
delay(20);
cleardevice();
}
//for moving circle in diagonal direction,the following loop works
for(i=50;i<=getmaxx();i++)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(i,i,50);
floodfill(i+2,i+2,3);
delay(20);
cleardevice();
}
//for moving circle in reverse diagonal direction,the following loop works
for(i=getmaxx();i>=0;i--)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(i,i,50);
floodfill(i+2,i+2,3);
delay(20);
cleardevice();
}
return 0;
//getch();
}



17.Man object animation

#include<stdio.h>
#include<graphics.h>

int main(){
int gd=DETECT,gm,i;
initgraph(&gd,&gm,NULL);
for(i=50;i<=getmaxx()-250;i++){
setcolor(7);
circle(50+i,50,30); // drawing head
floodfill(52+i,52,7);
setcolor(13);
line(50+i,80,50+i,200); //drawing body
line(50+i,110,20+i,140); //left hand
line(50+i,110,80+i,140); //right hand
line(50+i,200,20+i,230); //left leg
line(50+i,200,80+i,230); //right leg
delay(50);
cleardevice();
}
/*
for(i=getmaxy();i>=0;i--)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(i,50,50);
floodfill(i+2,52,3);
setcolor(7);
//setfillstyle(SOLID_FILL,10);
circle(i,50,30); // drawing head
floodfill(i+2,52,7);
setcolor(13);
line(i,80,i,200); //drawing body
line(i,110,i,140); //left hand
line(i,110,i,140); //right hand
line(50,200,i,230); //left leg
line(50,200,i,230); //right leg
delay(0);
cleardevice();
}

for(i=50;i<=getmaxy();i++)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(50,i,50);
floodfill(52,i+2,3);
delay(0);
//cleardevice();
}

for(i=getmaxy();i>=0;i--)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(50,i,50);
floodfill(52,i+2,3);
delay(0);
//cleardevice();
}

for(i=50;i<=getmaxx();i++)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(i,i,50);
floodfill(i+2,i+2,3);
delay(0);
//cleardevice();
}

for(i=getmaxx();i>=0;i--)
{
setcolor(3);
//setfillstyle(SOLID_FILL,9);
circle(i,i,50);
floodfill(i+2,i+2,3);
delay(0);
cleardevice();
}*/
cleardevice();
delay(1000);
closegraph();
return 0;
}



18.Hermite interpolation

#include <stdio.h> 
#include<graphics.h>

float dot(float *, float *);
void MtimesV(float [4][4], float *, float *);
void hermite_coeffs(float,float,float,float,float,float,float *);
float hermite(float *, float, float, float);
float  hermitemat[4][4]   = {{ 1, 0, 0, 0},
            { 0, 0, 1, 0},
            {-3, 3,-2,-1},
            { 2,-2, 1, 1} };


float dot(float *a, float *b){
  return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]+a[3]*b[3];
}

void MtimesV(float m[4][4], float *v, float *dst){
  int i,j;
  for(i=0;i<4;i++){
    dst[i]=0;
    for(j=0;j<4;j++)
      dst[i] += m[i][j]*v[j];
  }
}
void  hermite_coeffs(float t0, float t1, float y0, float y1, float ydot0, float ydot1, float *coeffs){
  float g[4];
  g[0]=y0; g[1]=y1; g[2]=ydot0*(t1 - t0);g[3]=ydot1*(t1 - t0);
  MtimesV(hermitemat,g,coeffs);
}
float hermite(float *coeffs, float t, float t0, float t1){
  float U[4] ;
  float u = (t - t0)/(t1 -t0);
  U[0] = 1 ; U[1] = u ;   U[2] = u*u ;    U[3] = u*u*u ;
  return dot(U,coeffs);
}

main(){
  float coeffs[4];
  float t0 = 0, t1 = 30;    /*  time interval */
  float y0 = 100,  y1 = 160;    /* start/stop values */
  float dy0 = .2, dy1 = 0;    /* start/stop speeds */
  int t;


hermite_coeffs(t0,t1,y0,y1,dy0,dy1,coeffs);
int gd=DETECT;
int gm;
initgraph(&gd,&gm,NULL);
for(t=0;t<31;t++){
float z=hermite(coeffs, (float) t, t0, t1) ;
putpixel(t,z,1);}
delay(1000);
closegraph();
return 0;

}

19.Bezier Interpolation

#include<stdio.h>
#include<graphics.h>
int main(){
int gd=DETECT,gm;
int x[4],y[4],px,py,i,n;
double t;
/*printf(&quot;Enter the no of control points 2 for linear Bezier 3 for Quadratic Bezier 4 for cubic
Bezier\n&quot;);
scanf(&quot;%d&quot;,&amp;n);
printf(&quot;Enter the control points of bezier curve: &quot;);*/
printf("enter the number of control points:\n");
scanf("%d",&n);

for(i=0;i<n;i++)
{
scanf("%d%d",&x[i],&y[i]);
//putpixel(x[i],y[i],GREEN);
}
initgraph(&gd,&gm,NULL);
for(i=0;i<n;i++)
{
//scanf(&quot;%d%d&quot;,&amp;x[i],&amp;y[i]);
putpixel(x[i],y[i],GREEN);
}
if(n==2){
for(t=0.0;t<=1.0;t+=0.001){
px=(1-t)*x[0]+x[1];
py=(1-t)*y[0]+y[1];
putpixel(px,py,WHITE);
delay(2);
}}

if (n==3){
for(t=0.0;t<=1.0;t+=0.001){
px=(1-t)*(1- t)*x[0]+2*t*(1-t)*x[1]+t*t*x[2];
py=(1-t)*(1- t)*y[0]+2*t*(1-t)*y[1]+t*t*y[2];
putpixel(px,py,WHITE);

delay(2);
}
}

if(n==4){
for(t=0.0;t<=1.0;t+=0.001){
px=(1-t)*(1- t)*(1-t)*x[0]+3*t*(1- t)*(1-t)*x[1]+3*t*t*(1- t)*x[2]+t*t*t*x[3];
py=(1-t)*(1- t)*(1-t)*y[0]+3*t*(1- t)*(1-t)*y[1]+3*t*t*(1- t)*y[2]+t*t*t*y[3];
putpixel(px,py,WHITE);
delay(2);
}
}
getch();
closegraph();
}

20. Painter's algorithm

#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;

int main(){
int gd=DETECT, gm;
    //detectgraph(&gd, &gm);
    initgraph(&gd, &gm," ");
setcolor(BLUE);
rectangle(50,50,200,200);
setcolor(RED);
floodfill(100,100,BLUE);
setcolor(GREEN);
circle(200,200,20);
floodfill(200,200,GREEN);
setcolor(YELLOW);
int points[]={100,100,30,20,100,20,100,100};
drawpoly(4,points);
setcolor(WHITE);
floodfill(35,25,YELLOW);
delay(1000);
closegraph();
return 0;
}



21.Gouraud shading

#include<stdio.h>
#include<stdlib.h>
#include<bits/stdc++.h>
using namespace std;

void shadeModeGouraud(int xi[],int Ip,int Ib,int Ia){
int i,j,temp,k;
for(j=0;j<k-1;j++){
for(i=0;i<k-1;i++){
if(xi[i]>xi[i+1]){
temp=xi[i];
xi[i]=xi[i+1];
xi[i]=temp;
}
}
for(i=0;i<k;i+=2){
float xa=xi[i],xb=xi[i+1];
float Ia=(a[0][2]*(y3-y1)+a[2][2]*(y-y1))/(y3-y1);
float Ib=(a[0][2]*(y3-y1)+a[2][2]*(y-y1))/(y3-y1);
while(xi[i]<xi[i+1]){
float Ip=(Ia*(xb-x[i][i]+Ib*(xi[i]-xa)))/(xb-xa);
int c=Ip;
putpixel(xi[i],y,c);
xi[i]++;
}
}
}
}

int main(){
int imat[r][c],i,j;
imat=mem_alloc(imat,r,c);
for(i=0;i<r;i++){
for(j=0;j<c;j++){
fscanf(fp,"%d",&imat[i][j]);
}
fprintf("\nFirst value of Ip,Ib,Ia");
}
for(i=0;i<r;i++){
imat[i][0]=shadeModeGouraud(imat[i],Ip,Ib,Ia);
for(j=0;j<r;j++){
imat[i][j]=shadeModeGouraud(imat[i][j],Ip,Is,Ia);
}
}
FILE *fp1;
fp1=fopen("out_image.pgm","wt");
fputs(s1,fp1);fputs(s2,fp1);
fprintf(fp1,"%d%d\n%d",c,r,max_pixel);
for(k=0;k<r;k++)
for(h=0;h<c;h++)
fprintf(fp1,"\n%d",imat[k][h]);
return 0;
}

22. Flat shading

#include<stdlib.h>
#include<cstring.h>

bool model(string fieval,vector<float>&vertices,vector<int>&indices){
string face;
string dataline,linechar;
vertices clear();indices_clear();
object.open(filename);
while(object>>line_char){
if(line_char=="V"){
for(int i=0;i<3;i++)
object>>point;
}
}
for(int i=0;i<indices.size();i++){
vertices.push_back(localvertices[i*3]);
vertices.push_back(localvertices[i*3+1]);
vertices.push_back(localvertices[i*3+2]);
vertices.push_back(localNormals[i*3]);
vertices.push_back(localNormals[i*3+1]);
vertices.push_back(localNormals[i*3+2]);
}
for(int k=0;k<3;i++){
bar3d(vertices.x1,vertices.y1,vertices.x2,vertices.y2,8,1);
indices.push_back(ind-1);
getline(object,face,11);
}
return true;
}

int main(){
int x[4],y[4],px,py,i,n;
double t;scanf("%d",&n);
for(i=0;i<n;i++)
 scanf("%d%d",&x[i],&y[i]);
imat=mem_alloc(imat,r,c);
for(i=0;i<r;i++){
for(j=0;j<c;j++){
fscanf(fp,"%d",&imat[i][j]);
}
}
imat=(int **)malloc(r*sizeof(int *));
for(i=0;i<r;i++)
imat[i]=0;
for(i=0;i<r;i++){
for(j=0;j<c;j++){
imat[i][j]=0;
return imat;
}
}
int h,k;
FILE *fp1;
fp1=fopen("out_image.pgm","wt");
fputs(s1,fp1);fputs(s2,fp1);
fprintf(fp1,"%d%d\n%d",c,r,max_pixel);
for(k=0;k<r;k++)
for(h=0;h<c;h++)
fprintf(fp1,"\n%d",imat[k][h]);
return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <graphics.h>

int xpt1[101], ypt1[101], xpt2[101], ypt2[101];

int sign(int x)
{
	if(x > 0)
	return 1;
	else return 0;
}

void CST(int x1, int y1, int x2, int y2, int xmn, int ymn, int xmx, int ymx)
{
	int e1 = 0, e2 = 0;
	if(sign(y1 - ymx))
	e1 |= (1<<2);
	if(sign(ymn - y1))
	e1 |= (1<<3);
	if(sign(x1 - xmx))
	e1 |= (1<<1);
	if(sign(xmn - x1))
	e1 |= (1<<0);
	if(sign(y2 - ymx))
	e2 |= (1<<2);
	if(sign(ymn - y2))
	e2 |= (1<<3);
	if(sign(x2 - xmx))
	e2 |= (1<<1);
	if(sign(xmn - x2))
	e2 |= (1<<0);
	double x1b, y1b, x2b, y2b;
	if(!e1 && !e2)
	{
		x1b = x1;
		y1b = y1;
		x2b = x2;
		y2b = y2;
	}
	else
	{
		if(e1 & e2)
		return;
		else
		{
			int i;
			if(!e1)
			{
				x1b = x1;
				y1b = y1;
				for(i=0;i<4;i++)
				{
					if((e1 & (1<<i)) == (e2 & (1<<i)))
					continue;
					else
					{
						if(i == 0)
						{
							x2b = xmn;
							y2b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmn - x1);	
						}
						else if(i == 1)
						{
							x2b = xmx;
							y2b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmx - x1);
						}
						else if(i == 2)
						{
							y2b = ymx;
							x2b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymx - y1);
						}
						else
						{
							y2b = ymn;
							x2b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymn - y1);
						}
					}
				}
			}
			else if(!e2)
			{
				x1b = x2;
				y1b = y2;
				for(i=0;i<4;i++)
				{
					if((e1 & (1<<i)) == (e2 & (1<<i)))
					continue;
					else
					{
						if(i == 0)
						{
							x2b = xmn;
							y2b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmn - x1);	
						}
						else if(i == 1)
						{
							x2b = xmx;
							y2b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmx - x1);
						}
						else if(i == 2)
						{
							y2b = ymx;
							x2b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymx - y1);
						}
						else
						{
							y2b = ymn;
							x2b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymn - y1);
						}
					}
				}
			}
			else
			{
				int ok = 0;
				for(i=0;i<4;i++)
				{
					if((e1 & (1<<i)) == (e2 & (1<<i)))
					continue;
					else
					{
						if(i == 0)
						{
							if(!ok)
							{
								ok = 1;
								x1b = xmn;
								y1b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmn - x1);
							}
							else
							{
								x2b = xmn;
								y2b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmn - x1);
							}	
						}
						else if(i == 1)
						{
							if(!ok)
							{
								ok = 1;
								x1b = xmx;
								y1b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmx - x1);
							}
							else
							{
								x2b = xmx;
								y2b = y1 + ((double)(y2 - y1)/(double)(x2 - x1)) * (xmx - x1);
							}
						}
						else if(i == 2)
						{
							if(!ok)
							{
								ok = 1;
								y1b = ymx;
								x1b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymx - y1);
							}
							else
							{
								y2b = ymx;
								x2b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymx - y1);
							}
						}
						else
						{
							if(!ok)
							{
								ok = 1;
								y1b = ymn;
								x1b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymn - y1);
							}
							else
							{
								y2b = ymn;
								x2b = x1 + ((double)(x2 - x1)/(double)(y2 - y1)) * (ymn - y1);
							}
						}
					}
				}
			}
		}
	}
	line(x1b, y1b, x2b, y2b);
	return;
}
				
int main(void)
{
	int gd = DETECT, gm = 0, n, xmn, xmx, ymn, ymx, i;
	scanf("%d %d %d %d %d", &n, &xmn, &ymn, &xmx, &ymx);
	for(i=0;i<n;i++)
	scanf("%d %d %d %d", xpt1 + i, ypt1 + i, xpt2 + i, ypt2 + i);
	initgraph(&gd, &gm, NULL);
	line(xmn, ymn, xmn, ymx);
	line(xmn, ymx, xmx, ymx);
	line(xmx, ymx, xmx, ymn);
	line(xmx, ymn, xmn, ymn);
	for(i=0;i<n;i++)
	CST(xpt1[i], ypt1[i], xpt2[i], ypt2[i], xmn, ymn, xmx, ymx);
	delay(10000);
	return 0;
}

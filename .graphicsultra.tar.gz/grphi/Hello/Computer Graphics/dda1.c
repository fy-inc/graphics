#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <graphics.h>

void DDA(int x1, int y1, int x2, int y2)
{
	int dx = x2 - x1, dy = y2 - y1;
	int steps = (fabs(dx) > fabs(dy)) ? fabs(dx) : fabs(dy);
	double x = x1;
	double y = y1;
	double xin = dx/(double)steps, yin = dy/(double)steps;
	for(int i=0;i<=steps;i++)
	{
		putpixel(x, y, WHITE);
		x += xin;
		y += yin;
	}
	return;
}	


void main()
{
	//INPUT 12 34 56 109
	int gd = DETECT, gm = 0, x1, y1, x2, y2;
	scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
	initgraph(&gd, &gm, NULL);
	DDA(x1, y1, x2, y2);
	delay(10000);
	return;
}	

#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

double xpt[101], ypt[101];

double TRANS(double c, double tr)
{
	return (c + tr);
}

double ROTX(double x, double y, double rang)
{
	return (x * cos(rang) - y * sin(rang));
}

double ROTY(double x, double y, double rang)
{
	return (x * sin(rang) + y * cos(rang));
}	

int main(void)
{
	int gd = DETECT, gm = 0;
	int n;
	double xt, yt, ang;
	scanf("%d", &n);
	for(int i=0;i<n;i++)
	scanf("%lf %lf", xpt + i, ypt + i);
	scanf("%lf %lf %lf", &xt, &yt, &ang);
	double rang = ((double)acos(-1) * ang)/(double)180;
	initgraph(&gd, &gm, NULL);
	for(int i=0;i<n-1;i++)
	line(xpt[i], ypt[i], xpt[i+1], ypt[i+1]);
	line(xpt[n-1], ypt[n-1], xpt[0], ypt[0]);
	delay(10000);
	for(int i=0;i<n;i++)	
	{
		xpt[i] = TRANS(xpt[i], -xt);
		ypt[i] = TRANS(ypt[i], -yt);
		double tx = xpt[i], ty = ypt[i];
		xpt[i] = ROTX(tx, ty, rang);
		ypt[i] = ROTY(tx, ty, rang);
		xpt[i] = TRANS(xpt[i], xt);
		ypt[i] = TRANS(ypt[i], yt);	
	}
	for(int i=0;i<n-1;i++)
	line(xpt[i], ypt[i], xpt[i+1], ypt[i+1]);
	line(xpt[n-1], ypt[n-1], xpt[0], ypt[0]);
	delay(10000);
	return 0;
}	

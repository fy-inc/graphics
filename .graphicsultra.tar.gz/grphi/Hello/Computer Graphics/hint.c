#include <stdio.h>
#include <graphics.h>
#include <math.h>
#include <stdlib.h>

void HERMITE(double x1, double y1, double x2, double y2, double m1, double m2)
{
	for(double u=0;u<=1;u+=0.001)
	{
		double x = (2*u*u*u - 3*u*u + 1)*x1 + (-2*u*u*u + 3*u*u)*x2 + (u*u*u - 2*u*u + 1)*m1 + (u*u*u - u*u)*m2;
		double y = (2*u*u*u - 3*u*u + 1)*y1 + (-2*u*u*u + 3*u*u)*y2 + (u*u*u - 2*u*u + 1)*m1 + (u*u*u - u*u)*m2;
		putpixel(x, y, WHITE);
	}
	return;
}	

int main(void)
{
	//INPUT 10 10 100 34 54 -134 
	int gd = DETECT, gm = 0;
        double x1, y1, x2, y2, m1, m2;
	scanf("%lf %lf %lf %lf %lf %lf", &x1, &y1, &x2, &y2, &m1, &m2);
	initgraph(&gd, &gm, NULL);
	HERMITE(x1, y1, x2, y2, m1, m2);
	delay(10000);
	return 0;
}	

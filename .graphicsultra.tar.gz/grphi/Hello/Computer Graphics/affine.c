#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

double xpt[101], ypt[101], rxpt[101], rypt[101];
double scl[3][3], shr[3][3], rot[3][3];

void SCL(int x)
{
	double arr[3], res[3];
	arr[0] = xpt[x];
	arr[1] = ypt[x];
	arr[2] = 1;
	res[0] = 0;
	res[1] = 0;
	res[2] = 0;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<1;j++)
		{
			for(int k=0;k<3;k++)
			res[i] += scl[i][k] * arr[k];
		}
	}
	rxpt[x] = res[0];
	rypt[x] = res[1];
	return;
}	

void SHR(int x)
{
	double arr[3], res[3];
	arr[0] = xpt[x];
	arr[1] = ypt[x];
	arr[2] = 1;
	res[0] = 0;
	res[1] = 0;
	res[2] = 0;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<1;j++)
		{
			for(int k=0;k<3;k++)
			res[i] += shr[i][k] * arr[k];
		}
	}
	rxpt[x] = res[0];
	rypt[x] = res[1];
	return;
}	

void ROTT(int x)
{
	double arr[3], res[3];
	arr[0] = xpt[x];
	arr[1] = ypt[x];
	arr[2] = 1;
	res[0] = 0;
	res[1] = 0;
	res[2] = 0;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<1;j++)
		{
			for(int k=0;k<3;k++)
			res[i] += rot[i][k] * arr[k];
		}
	}
	rxpt[x] = res[0];
	rypt[x] = res[1];
	return;
}	

int main(void)
{
	int gd = DETECT, gm = 0;
	int n;
	scanf("%d", &n);
	for(int i=0;i<n;i++)
	scanf("%lf %lf", xpt + i, ypt + i);
	double scfx, scfy, shfx, shfy, ang;
	scanf("%lf %lf %lf %lf %lf", &scfx, &scfy, &shfx, &shfy, &ang);
	double rang = ((double)acos(-1) * ang)/(double)180;
	scl[0][0] = scfx;
	scl[1][1] = scfy;
	scl[2][2] = 1;
	shr[0][0] = 1;
	shr[0][1] = shfx;
	shr[1][0] = shfy;
	shr[1][1] = 1;
	shr[2][2] = 1;
	rot[0][0] = cos(rang);
	rot[0][1] = -sin(rang);
	rot[1][0] = sin(rang);
	rot[1][1] = cos(rang);
	rot[2][2] = 1;
	initgraph(&gd, &gm, NULL);
	for(int i=0;i<n-1;i++)
	line(xpt[i], ypt[i], xpt[i+1], ypt[i+1]);
	line(xpt[n-1], ypt[n-1], xpt[0], ypt[0]);
	for(int i=0;i<n;i++)
	SCL(i);	
	for(int i=0;i<n-1;i++)
	line(rxpt[i], rypt[i], rxpt[i+1], rypt[i+1]);
	line(rxpt[n-1], rypt[n-1], rxpt[0], rypt[0]);
	for(int i=0;i<n;i++)
	SHR(i);	
	for(int i=0;i<n-1;i++)
	line(rxpt[i], rypt[i], rxpt[i+1], rypt[i+1]);
	line(rxpt[n-1], rypt[n-1], rxpt[0], rypt[0]);
	for(int i=0;i<n;i++)
	ROTT(i);	
	for(int i=0;i<n-1;i++)
	line(rxpt[i], rypt[i], rxpt[i+1], rypt[i+1]);
	line(rxpt[n-1], rypt[n-1], rxpt[0], rypt[0]);
	delay(10000);
	return 0;
}	

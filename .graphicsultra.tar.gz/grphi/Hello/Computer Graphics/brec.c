#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <graphics.h>

void BREC(int r, int x0, int y0)
{
	int x = 0, y = r;
	putpixel(x + x0, y + y0, WHITE);
	putpixel(-x + x0, -y + y0, WHITE);
	putpixel(y + x0, x + y0, WHITE);
	putpixel(-y + x0, -x + y0, WHITE);
	int D = 3 - 2*r;
	while(x <= y)
	{
		if(D < 0)
		{
			x++;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(y + x0, x + y0, WHITE);
			putpixel(-y + x0, -x + y0, WHITE);
			putpixel(y + x0, -x + y0, WHITE);
			putpixel(-y + x0, x + y0, WHITE);
			D += 4*x + 6;
		}
		else
		{
			x++;
			y--;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(y + x0, x + y0, WHITE);
			putpixel(-y + x0, -x + y0, WHITE);
			putpixel(y + x0, -x + y0, WHITE);
			putpixel(-y + x0, x + y0, WHITE);
			D += 4*(x - y) + 10;
		}
	}
	return;
}	

void main()
{
	//INPUT 45 308 205
	int gd = DETECT, gm = 0, r, x0, y0;
	scanf("%d %d %d", &r, &x0, &y0);
	initgraph(&gd, &gm, NULL);
	BREC(r, x0, y0);
	delay(10000);
	return;
}	

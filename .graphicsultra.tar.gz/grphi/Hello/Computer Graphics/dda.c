#include <stdio.h>
#include <graphics.h>

void main()
{
	int gd = DETECT, gm = 0, x1, y1;
	scanf("%d %d", &x1, &y1);
	initgraph(&gd, &gm, NULL);
	putpixel(x1, y1, RED);
	delay(10000);
	return;
}	

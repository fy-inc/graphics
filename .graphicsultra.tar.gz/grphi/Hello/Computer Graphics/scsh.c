#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

int xpt[101], ypt[101];

int SCALE(int c, int scf)
{
	return (c * scf);
}

int SHX(int x, int y, int shf)
{
	return (x + shf * y);
}

int SHY(int x, int y, int shf)
{
	return (shf * x + y);
}	

int main(void)
{
	int gd = DETECT, gm = 0;
	int n, scfx, scfy, shf;
	scanf("%d", &n);
	for(int i=0;i<n;i++)
	scanf("%d %d", xpt + i, ypt + i);
	scanf("%d %d %d", &scfx, &scfy, &shf);
	initgraph(&gd, &gm, NULL);
	for(int i=0;i<n-1;i++)
	line(xpt[i], ypt[i], xpt[i+1], ypt[i+1]);	
	line(xpt[n-1], ypt[n-1], xpt[0], ypt[0]);
	delay(10000);
	for(int i=0;i<n;i++)
	{
		xpt[i] = SCALE(xpt[i], scfx);
		ypt[i] = SCALE(ypt[i], scfy);
		xpt[i] = SHX(xpt[i], ypt[i], shf);
	}
	for(int i=0;i<n-1;i++)
	line(xpt[i], ypt[i], xpt[i+1], ypt[i+1]);	
	line(xpt[n-1], ypt[n-1], xpt[0], ypt[0]);
	delay(10000);
	return 0;
}	

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int rx[205][205], gx[205][205], bx[205][205];

void MPTC(int r, int x0, int y0, int rh, int gh, int bh)
{
	int x = 0, y = r;
	rx[x + x0][y + y0] = rh;
	rx[-x + x0][-y + y0] = rh;
	rx[y + x0][x + y0] = rh;
	rx[-y + x0][-x + y0] = rh;
	gx[x + x0][y + y0] = gh;
	gx[-x + x0][-y + y0] = gh;
	gx[y + x0][x + y0] = gh;
	gx[-y + x0][-x + y0] = gh;
	bx[x + x0][y + y0] = bh;
	bx[-x + x0][-y + y0] = bh;
	bx[y + x0][x + y0] = bh;
	bx[-y + x0][-x + y0] = bh;
	double p = (double)5/(double)4 - r;
	while(x <= y)
	{
		if(p < 0)
		{
			x++;
			rx[x + x0][y + y0] = rh;
			rx[-x + x0][-y + y0] = rh;
			rx[x + x0][-y + y0] = rh;
			rx[-x + x0][y + y0] = rh;
			rx[y + x0][x + y0] = rh;
			rx[-y + x0][-x + y0] = rh;
			rx[y + x0][-x + y0] = rh;
			rx[-y + x0][x + y0] = rh;
			gx[x + x0][y + y0] = gh;
			gx[-x + x0][-y + y0] = gh;
			gx[x + x0][-y + y0] = gh;
			gx[-x + x0][y + y0] = gh;
			gx[y + x0][x + y0] = gh;
			gx[-y + x0][-x + y0] = gh;
			gx[y + x0][-x + y0] = gh;
			gx[-y + x0][x + y0] = gh;
			bx[x + x0][y + y0] = bh;
			bx[-x + x0][-y + y0] = bh;
			bx[x + x0][-y + y0] = bh;
			bx[-x + x0][y + y0] = bh;
			bx[y + x0][x + y0] = bh;
			bx[-y + x0][-x + y0] = bh;
			bx[y + x0][-x + y0] = bh;
			bx[-y + x0][x + y0] = bh;
			p += 2*x + 1;
		}
		else
		{
			x++;
			y--;
			rx[x + x0][y + y0] = rh;
			rx[-x + x0][-y + y0] = rh;
			rx[x + x0][-y + y0] = rh;
			rx[-x + x0][y + y0] = rh;
			rx[y + x0][x + y0] = rh;
			rx[-y + x0][-x + y0] = rh;
			rx[y + x0][-x + y0] = rh;
			rx[-y + x0][x + y0] = rh;
			gx[x + x0][y + y0] = gh;
			gx[-x + x0][-y + y0] = gh;
			gx[x + x0][-y + y0] = gh;
			gx[-x + x0][y + y0] = gh;
			gx[y + x0][x + y0] = gh;
			gx[-y + x0][-x + y0] = gh;
			gx[y + x0][-x + y0] = gh;
			gx[-y + x0][x + y0] = gh;
			bx[x + x0][y + y0] = bh;
			bx[-x + x0][-y + y0] = bh;
			bx[x + x0][-y + y0] = bh;
			bx[-x + x0][y + y0] = bh;
			bx[y + x0][x + y0] = bh;
			bx[-y + x0][-x + y0] = bh;
			bx[y + x0][-x + y0] = bh;
			bx[-y + x0][x + y0] = bh;
			p += 2*(x - y) + 1;
		}
	}
	return;
}

void MPTE(int a, int b, int x0, int y0, int rh, int gh, int bh)
{
	int x = 0, y = b;
	double pr1 = b*b + a*a/(double)4 - a*a*b;
	rx[x + x0][y + y0] = rh;
	rx[-x + x0][-y + y0] = rh;
	gx[x + x0][y + y0] = gh;
	gx[x + x0][y + y0] = gh;
	bx[-x + x0][-y + y0] = bh;
	bx[-x + x0][-y + y0] = bh;
	while(2*b*b*x <= 2*a*a*y)
	{
		if(pr1 < 0)
		{
			x++;
			rx[x + x0][y + y0] = rh;
			rx[-x + x0][-y + y0] = rh;
			rx[-x + x0][y + y0] = rh;
			rx[x + x0][-y + y0] = rh;
			gx[x + x0][y + y0] = gh;
			gx[x + x0][y + y0] = gh;
			gx[-x + x0][-y + y0] = gh;
			gx[-x + x0][y + y0] = gh;
			bx[x + x0][-y + y0] = bh;
			bx[-x + x0][-y + y0] = bh;
			bx[-x + x0][y + y0] = bh;
			bx[x + x0][-y + y0] = bh;
			pr1 += 2*b*b*x + b*b;
		}
		else
		{
			x++;
			y--;
			rx[x + x0][y + y0] = rh;
			rx[-x + x0][-y + y0] = rh;
			rx[-x + x0][y + y0] = rh;
			rx[x + x0][-y + y0] = rh;
			gx[x + x0][y + y0] = gh;
			gx[x + x0][y + y0] = gh;
			gx[-x + x0][-y + y0] = gh;
			gx[-x + x0][y + y0] = gh;
			bx[x + x0][-y + y0] = bh;
			bx[-x + x0][-y + y0] = bh;
			bx[-x + x0][y + y0] = bh;
			bx[x + x0][-y + y0] = bh;
			pr1 += 2*b*b*x - 2*a*a*y + b*b;
		}
	}
	double pr2 = b*b*(x + 1/(double)2)*(x + 1/(double)2) + a*a*(y - 1)*(y - 1) - a*a*b*b;
	while(y >= 0)
	{
		if(pr2 > 0)
		{
			y--;
			rx[x + x0][y + y0] = rh;
			rx[-x + x0][-y + y0] = rh;
			rx[-x + x0][y + y0] = rh;
			rx[x + x0][-y + y0] = rh;
			gx[x + x0][y + y0] = gh;
			gx[x + x0][y + y0] = gh;
			gx[-x + x0][-y + y0] = gh;
			gx[-x + x0][y + y0] = gh;
			bx[x + x0][-y + y0] = bh;
			bx[-x + x0][-y + y0] = bh;
			bx[-x + x0][y + y0] = bh;
			bx[x + x0][-y + y0] = bh;
			pr2 += a*a - 2*a*a*y;
		}
		else
		{
			y--;
			x++;
			rx[x + x0][y + y0] = rh;
			rx[-x + x0][-y + y0] = rh;
			rx[-x + x0][y + y0] = rh;
			rx[x + x0][-y + y0] = rh;
			gx[x + x0][y + y0] = gh;
			gx[x + x0][y + y0] = gh;
			gx[-x + x0][-y + y0] = gh;
			gx[-x + x0][y + y0] = gh;
			bx[x + x0][-y + y0] = bh;
			bx[-x + x0][-y + y0] = bh;
			bx[-x + x0][y + y0] = bh;
			bx[x + x0][-y + y0] = bh;
			pr2 += 2*b*b*x - 2*a*a*y + a*a;
		}
	}
	return;
}

void ffill(int xp, int yp, int rh, int gh, int bh)
{
	if((xp < 0) || (xp >= 201) || (yp < 0) || (yp >= 201) || (rx[xp][yp] == rh))
	return;
	rx[xp][yp] = rh;
	gx[xp][yp] = gh;
	bx[xp][yp] = bh;
	ffill(xp + 1, yp, rh, gh, bh);
	ffill(xp, yp + 1, rh, gh, bh);
	ffill(xp - 1, yp, rh, gh, bh);
	ffill(xp, yp - 1, rh, gh, bh);
	return;
}

int main(void)
{
	FILE *FX = fopen("imax.ppm", "a");
	if(FX == NULL)
	{
		printf("ERROR\n");
		return 0;
	}	
	ffill(100, 100, 50, 10, 200);
	MPTC(25, 100, 100, 200, 50, 10);
	ffill(100, 100, 200, 50, 10);
	MPTE(25, 17.5, 100, 100, 10, 200, 50);
	ffill(100, 100, 10, 200, 50);
	for(int i=0;i<201;i++)
	{
		for(int j=0;j<201;j++)
		fprintf(FX, "%d %d %d ", rx[i][j], gx[i][j], bx[i][j]);
	}
	fclose(FX);
	return 0;
}	

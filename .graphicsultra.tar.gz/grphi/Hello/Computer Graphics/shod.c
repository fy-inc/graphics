#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <math.h>

double xpt[101], ypt[101], txpt[101], typt[101];

void SUTHOG(int xmn, int ymn, int xmx, int ymx, int *z)
{
	//CASE 1 :- WHEN x = xmn
	int nx1 = 0, n = *z;
	for(int i=0;i<n;i++)
	{
		if(xpt[i] < xmn && xpt[(i+1)%n] < xmn)
		continue;
		else if(xpt[i] >= xmn && xpt[(i+1)%n] >= xmn)
		{
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(xpt[i] < xmn && xpt[(i+1)%n] >= xmn)
		{
			double xi = xmn;
			double yi = ypt[i] + (double)((ypt[(i+1)%n] - ypt[i]) * (xmn - xpt[i]))/(double)(xpt[(i+1)%n] - xpt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(xpt[i] >= xmn && xpt[(i+1)%n] < xmn)
		{
			double xi = xmn;
			double yi = ypt[i] + (double)((ypt[(i+1)%n] - ypt[i]) * (xmn - xpt[i]))/(double)(xpt[(i+1)%n] - xpt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
		}
	}
	n = nx1;
	for(int i=0;i<nx1;i++)
	{
		xpt[i] = txpt[i];
		ypt[i] = typt[i];
	}
	//CASE 2 :- WHEN x = xmx
	nx1 = 0;
	for(int i=0;i<n;i++)
	{
		if(xpt[i] > xmx && xpt[(i+1)%n] > xmx)
		continue;
		else if(xpt[i] <= xmx && xpt[(i+1)%n] <= xmx)
		{
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(xpt[i] > xmx && xpt[(i+1)%n] <= xmx)
		{
			double xi = xmx;
			double yi = ypt[i] + (double)((ypt[(i+1)%n] - ypt[i]) * (xmx - xpt[i]))/(double)(xpt[(i+1)%n] - xpt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(xpt[i] <= xmx && xpt[(i+1)%n] > xmx)
		{
			double xi = xmx;
			double yi = ypt[i] + (double)((ypt[(i+1)%n] - ypt[i]) * (xmx - xpt[i]))/(double)(xpt[(i+1)%n] - xpt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
		}
	}
	n = nx1;
	for(int i=0;i<nx1;i++)
	{
		xpt[i] = txpt[i];
		ypt[i] = typt[i];
	}
	//CASE 3 :- WHEN y = ymn
	nx1 = 0;
	for(int i=0;i<n;i++)
	{
		if(ypt[i] < ymn && ypt[(i+1)%n] < ymn)
		continue;
		else if(ypt[i] >= ymn && ypt[(i+1)%n] >= ymn)
		{
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(ypt[i] < ymn && ypt[(i+1)%n] >= ymn)
		{
			double yi = ymn;
			double xi = xpt[i] + (double)((xpt[(i+1)%n] - xpt[i]) * (ymn - ypt[i]))/(double)(ypt[(i+1)%n] - ypt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(ypt[i] >= ymn && ypt[(i+1)%n] < ymn)
		{
			double yi = ymn;
			double xi = xpt[i] + (double)((xpt[(i+1)%n] - xpt[i]) * (ymn - ypt[i]))/(double)(ypt[(i+1)%n] - ypt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
		}
	}
	n = nx1;
	for(int i=0;i<nx1;i++)
	{
		xpt[i] = txpt[i];
		ypt[i] = typt[i];
	}
	//CASE 4 :- WHEN y = ymx
	nx1 = 0;
	for(int i=0;i<n;i++)
	{
		if(ypt[i] > ymx && ypt[(i+1)%n] > ymx)
		continue;
		else if(ypt[i] <= ymx && ypt[(i+1)%n] <= ymx)
		{
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(ypt[i] > ymx && ypt[(i+1)%n] <= ymx)
		{
			double yi = ymx;
			double xi = xpt[i] + (double)((xpt[(i+1)%n] - xpt[i]) * (ymx - ypt[i]))/(double)(ypt[(i+1)%n] - ypt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
			txpt[nx1] = xpt[(i+1)%n];
			typt[nx1] = ypt[(i+1)%n];
			nx1++;
		}
		else if(ypt[i] <= ymx && ypt[(i+1)%n] > ymx)
		{
			double yi = ymx;
			double xi = xpt[i] + (double)((xpt[(i+1)%n] - xpt[i]) * (ymx - ypt[i]))/(double)(ypt[(i+1)%n] - ypt[i]);
			txpt[nx1] = xi;
			typt[nx1] = yi;
			nx1++;
		}
	}
	n = nx1;
	for(int i=0;i<nx1;i++)
	{
		xpt[i] = txpt[i];
		ypt[i] = typt[i];
	}
	*z = n;
	for(int i=0;i<n;i++)
	line(xpt[i], ypt[i], xpt[(i+1)%n], ypt[(i+1)%n]);
	return;
}
				
int main(void)
{
	int gd = DETECT, gm = 0, xmn, ymn, xmx, ymx, n, i;
	scanf("%d %d %d %d %d", &n, &xmn, &ymn, &xmx, &ymx);
        for(i=0;i<n;i++)
 	scanf("%lf %lf", xpt + i, ypt + i);
	initgraph(&gd, &gm, NULL);
	line(xmn, ymn, xmn, ymx);
	line(xmn, ymx, xmx, ymx);
	line(xmx, ymx, xmx, ymn);
	line(xmx, ymn, xmn, ymn);
	SUTHOG(xmn, ymn, xmx, ymx, &n);
	delay(10000);
	return 0;
}	

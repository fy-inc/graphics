#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <graphics.h>

int xpt[101], ypt[101];

void ffill(int xp, int yp)
{
	if((getpixel(xp, yp) == WHITE) || (getpixel(xp, yp) == BLUE))
	return;
	putpixel(xp, yp, BLUE);
	ffill(xp + 1, yp);
	ffill(xp, yp + 1);
	ffill(xp - 1, yp);
	ffill(xp, yp - 1);
	return;
}

int main(void)
{
	int gd = DETECT, gm = 0, n, i;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	scanf("%d %d", xpt + i, ypt + i);
	initgraph(&gd, &gm, NULL);
	for(i=0;i<n;i++)
	line(2*xpt[i], 2*ypt[i], 2*xpt[(i+1)%n], 2*ypt[(i+1)%n]);
	ffill(2*xpt[0], 2*ypt[0] + 1);
	delay(10000);
	return 0;
}	

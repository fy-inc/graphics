#include <stdio.h>
#include <graphics.h>
#include <math.h>
#include <stdlib.h>

void BRES(int x1, int y1, int x2, int y2)
{
	int dx = x2 - x1, dy = y2 - y1;
	int p = 2*dy - dx;
	int x = x1, y = y1;
	putpixel(x, y, WHITE);
	for(int i=0;i<3*(dx-1);i++)
	{
		if(p < 0)
		{
			x++;
			p += 2*dy;
			putpixel(x, y, WHITE);
		}
		else
		{
			x++;
			y++;
			p += 2*(dy - dx);
			putpixel(x, y, WHITE);
		}
	}
	return;
}	

void main()
{
	//INPUT 12 34 56 109
	int gd = DETECT, gm = 0, x1, y1, x2, y2;
	scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
	initgraph(&gd, &gm, NULL);
	BRES(x1, y1, x2, y2);
	delay(10000);
	return;
}	

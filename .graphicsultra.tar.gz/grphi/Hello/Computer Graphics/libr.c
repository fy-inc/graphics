#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

int xpt1[101], ypt1[101], xpt2[101], ypt2[101];

void LIANG(int x1, int y1, int x2, int y2, int xmn, int ymn, int xmx, int ymx)
{
	int p[4], q[4];
	int dx = x2 - x1;
	int dy = y2 - y1;
	p[0] = -dx, q[0] = x1 - xmn, p[1] = dx, q[1] = xmx - x1, p[2] = -dy, q[2] = y1 - ymn, p[3] = dy, q[3] = ymx - y1;
	int i;
	double u1 = 0, u2 = 1;
	for(i=0;i<4;i++)
	{
		if((p[i] == 0) && (q[i] < 0))
		continue;
		else	
		{
			if(p[i] < 0)
			{
				double r = (double)q[i]/(double)p[i];
				if(u1 < r)
				u1 = r;
			}
			if(p[i] > 0)
			{
				double r = (double)q[i]/(double)p[i];
				if(u2 > r)
				u2 = r;
			}
		}		 	
	}
	if(u1 < u2)
	line(x1 + u1*dx, y1 + u1*dy, x1 + u2*dx, y1 + u2*dy);
	return;
}

int main(void)
{
	int gd = DETECT, gm = 0, xmn, ymn, xmx, ymx, n, i;
	scanf("%d %d %d %d %d", &n, &xmn, &ymn, &xmx, &ymx);
	for(i=0;i<n;i++)
	scanf("%d %d %d %d", xpt1 + i, ypt1 + i, xpt2 + i, ypt2 + i);
	initgraph(&gd, &gm, NULL);
	line(xmn, ymn, xmn, ymx);
	line(xmn, ymx, xmx, ymx);
	line(xmx, ymx, xmx, ymn);
	line(xmx, ymn, xmn, ymn);
	for(i=0;i<n;i++)
	LIANG(xpt1[i], ypt1[i], xpt2[i], ypt2[i], xmn, ymn, xmx, ymx);
	delay(10000);
	return 0;
}	

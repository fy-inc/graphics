#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int X1=50,Y1=275,X2=150,Y2=400,X3=150,Y3=350,X4=200,Y4=400,X5=75,Y5=410,X6=175,Y6=410,r=10;
	int col=15;
		
	for(int i=0;i<400;i++){
		cleardevice();
		setcolor(col);
		bar(X1+i,Y1,X2+i,Y2);
		bar(X3+i,Y3,X4+i,Y4);
		circle(X5+i,Y5,r);
		circle(X6+i,Y6,r);
		delay(30);
		if(i%20==0)
		col++;
		if(col==16)col=2;
	}
	getchar();
	closegraph();
}		


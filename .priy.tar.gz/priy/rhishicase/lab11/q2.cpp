#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
class Point{
	public:
	double x,y,z;
	Point(double _x,double _y,double _z){
		x=_x;
		y=_y;
		z=_z;	
	}
	Point(){
		x=0;
		y=0;
		z=0;
	}
	Point operator +(Point yy){
		return Point(x+yy.x,y+yy.y,z+yy.z);
	}
	Point operator /(double v){
		return Point(x/v,y/v,z/v);
	}
};
double z[500][500];
int c[500][500];
void draw(vector<Point> &p,int col){
	Point ct;
	for(Point r:p)
		ct=ct+r;
	ct=ct/p.size();
	set< pair<int,int> > sm;
	for(int i=0;i<p.size();i++)
		line(p[i].x,p[i].y,p[(i+1)%p.size()].x,p[(i+1)%p.size()].y);
	for(int i=0;i<400;i++)
		for(int j=0;j<300;j++)
			if(getpixel(i,j)==WHITE)
				sm.insert(make_pair(i,j));
	cleardevice();	
}	
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);	
	Point A(100,50,10),B(360,60,10),C(250,250,10),D(100,250,10),E(150,50,15),F(300,100,10),G(250,150,10);
	vector<Point> p1={A,B,C,D};
	vector<Point> p2={E,F,G};
	draw(p2,RED);
	draw(p1,GREEN);
	for(int i=0;i<400;i++)
		for(int j=0;j<300;j++)
			putpixel(i,j,c[i][j]);
				
	getchar();
	closegraph();		
	return 0;
}

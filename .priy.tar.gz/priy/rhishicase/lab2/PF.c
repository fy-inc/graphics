#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;
struct point{
	int x,y;
};
typedef struct point point;
typedef struct pointD pointD;
struct Line{
	point p1,p2;
	int a,b,c;//ax+by=c;
};
typedef struct Line Line;
Line makeLine(point p1,point p2){
	Line l;
	l.p1=p1;
	l.p2=p2;
	l.a=p2.y-p1.y;
	l.b=-(p2.x-p1.x);
	l.c=(p2.y-p1.y)*p1.x-(p2.x-p1.x)*p1.y;
	return l;
}
int gcd(int a,int b){
	return (b==0)?a:(gcd(b,a%b));
}
int minY(Line l){
	return min(l.p1.y,l.p2.y);
}

int maxY(Line l){
	return max(l.p1.y,l.p2.y);
}
int minX(Line l){
	return min(l.p1.x,l.p2.x);
}

int maxX(Line l){
	return max(l.p1.x,l.p2.x);
}
point toPoint(int x){
	point ans;
	ans.x=x;
	ans.y=1;
	return ans;
}
point intersectX(Line l,int y){
	point ans;
	if((minY(l)==maxY(l)&&minY(l)==y)){
		ans.x=-2;
		return ans;
	}	
	if(y<minY(l)||y>=maxY(l)){
		ans.x=-1;
		return ans;
	}
	
	int num=l.c-l.b*y;
	int den=l.a;
	
	int g=gcd(abs(num),abs(den));
	if(g!=0){
		num/=g;
		den/=g;
	}
	if(den<0){
		num*=-1;
		den*=-1;
	}
	ans.x=num;
	ans.y=den;
	return ans;	
}

point P[]={{100,30},{50,70},{70,70},{30,150},{150,150}};
void DDA(int x1,int y1,int x2,int y2){
	int dx=x2-x1;
	int dy=y2-y1;
	int steps;
	if(abs(dx)>abs(dy))
		steps=abs(dx);
	else
		steps=abs(dy);
	double xinc=dx/((double)steps);
	double yinc=dy/((double)steps);
	double x=x1,y=y1;
	for(int i=0;i<steps;i++){
		putpixel((int)floor(x),(int)floor(y),WHITE);
		x+=xinc;
		y+=yinc;
		delay(1);
				
	}
	return ;
}
bool cmp(const point& a,const point& b){
	return a.x*b.y<=b.x*a.y;
}
void polyDraw(){
	vector<Line> L;
	for(int i=0;i<5;i++){
		L.push_back(makeLine(P[i],P[(i+1)%5]));
	}
	for(int i=0;i<5;i++)
		DDA(P[i].x,P[i].y,P[(i+1)%5].x,P[(i+1)%5].y);
	
	int ymin=1000000000,ymax=0;
	for(int i=0;i<5;i++){
		ymin=min(ymin,P[i].y);
		ymax=max(ymax,P[i].y);
	}
	for(int y=ymin;y<=ymax;y++){
		vector<point> v;
		for(int ii=0;ii<5;ii++){
			Line &x=L[ii];
			point p=intersectX(x,y);
			if(p.x==-1){
				continue;
			}
			else if(p.x==-2){
				continue;
				v.push_back(toPoint(minX(x)));
				v.push_back(toPoint(maxX(x)));
			}
			else
				v.push_back(p);
		}
		if(v.empty())
			continue;
		sort(v.begin(),v.end(),cmp);
		for(int i=0;i<v.size()-1;i+=2){
			for(int x=(v[i].x+v[i].y-1)/v[i].y;x<v[i+1].x/v[i+1].y;x++){
				putpixel(x,y,WHITE);
delay(1);
				
			}

		}
	}
	
}
int main(){
	
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	polyDraw();
	
	int in = 0;

	while (in == 0) {
	    in = getchar();
	}

	closegraph();
	return 0;
} 

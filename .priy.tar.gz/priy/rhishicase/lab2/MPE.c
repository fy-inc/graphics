#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
void DE(int x,int y,int xc,int yc){
	putpixel(xc+x,yc+y,WHITE);
	putpixel(xc-x,yc+y,WHITE);
	putpixel(xc+x,yc-y,WHITE);
	putpixel(xc-x,yc-y,WHITE);
}
void MPE(){
	int xc=100,yc=100;
	int rx=50,ry=35;
	int x=0,y=ry;
	double p=ry*ry+0.25*rx*rx-rx*ry*ry;
	DE(x,y,xc,yc);
	while(2*ry*ry*x<2*rx*rx*y){
		x++;
		if(p<0){
			p+=2*ry*ry*x+ry*ry;
		}else{
			y--;
			p+=2*ry*ry*x-2*rx*rx*y+ry*ry;
		}
		DE(x,y,xc,yc);
		delay(100);
		
	}
	p=ry*ry*(x+0.5)*(x+0.5)+rx*rx*(y-1.0)*(y-1.0)-1.0*rx*rx*ry*ry;
		
	DE(x,y,xc,yc);
	while(y>0){
		y--;
		if(p>0){
			p+=-2*rx*rx*y+rx*rx;
		}else{
			x++;
			p+=2*ry*ry*x-2*rx*rx*y+rx*rx;
		}
		DE(x,y,xc,yc);
		delay(100);
	}
			
	return ;		
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	MPE();
	getchar();
	closegraph();	
	return 0;
}

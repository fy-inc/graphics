#include"../lab3/geometry.cpp"
vector<Point> clip(int xmin,int ymin,int xmax,int ymax,vector<Point> v){
	double dx=v[1].x-v[0].x,dy=v[1].y-v[0].y;
	double p[]={-dx,dx,-dy,dy};
	double q[]={v[0].x-xmin,xmax-v[0].x,v[0].y-ymin,ymax-v[0].y};
	double u1=0,u2=1;
	for(int i=0;i<4;i++){
		if(p[i]==0&&q[i]<0){
			v.clear();
			return v;
		}
		if(p[i]<0)
			u1=max(u1,q[i]/p[i]);
		else if(p[i]>0)
			u2=min(u2,q[i]/p[i]);
	}
	if(u1>u2){
		v.clear();
	}else if(u1==0){
		v[1].x=v[0].x+u2*dx;
		v[1].y=v[0].y+u2*dy;
	}else{
		v[1].x=v[0].x+u2*dx;
		v[1].y=v[0].y+u2*dy;
		v[0].x=v[0].x+u1*dx;
		v[0].y=v[0].y+u1*dy;
	}
	
	return v;
}				
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int xmin=40,ymin=40,xmax=100,ymax=80;
	vector< vector<Point> > L={{{30,65},{55,30}},
				   {{60,20},{110,90}},
				   {{60,100},{80,70}},
				   {{85,50},{120,75}}};
	for(vector<Point> v:L){
		rectangle(xmin,ymin,xmax,ymax);
		line(v[0].x,v[0].y,v[1].x,v[1].y);
		getchar();
		cleardevice();
		rectangle(xmin,ymin,xmax,ymax);
		vector<Point> p=clip(xmin,ymin,xmax,ymax,v);
		if(!p.empty())
			line(p[0].x,p[0].y,p[1].x,p[1].y);
		getchar();
		cleardevice();
	}
	closegraph();
	return 0;
}	

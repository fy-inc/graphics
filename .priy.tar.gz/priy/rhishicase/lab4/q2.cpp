#include"../lab3/geometry.cpp"
int ABOVE=1,BELOW=2,LEFT=4,RIGHT=8;
int getRegionCode(Point p,int xmin,int ymin,int xmax,int ymax){
	int ans=0;
	if(p.y-ymax>0)
		ans+=ABOVE;
	if(ymin-p.y>0)
		ans+=BELOW;
	if(p.x-xmax>0)
		ans+=RIGHT;
	if(xmin-p.x>0)
		ans+=LEFT;
	return ans;
}
double intersectY(vector<Point> p,double x){
	return p[0].y+(p[1].y-p[0].y)*(x-p[0].x)/(p[1].x-p[0].x);
}
double intersectX(vector<Point> p,double y){
	return p[0].x+(p[1].x-p[0].x)*(y-p[0].y)/(p[1].y-p[0].y);
}
vector<Point> clip(int xmin,int ymin,int xmax,int ymax,vector<Point> v){
	int c1=getRegionCode(v[0],xmin,ymin,xmax,ymax);
	int c2=getRegionCode(v[1],xmin,ymin,xmax,ymax);	
	if(c1==0&&c2==0)
		return v;
	if(c1&c2){
		v.clear();
		return v;
	}
	//above
	if((c1^c2)&BELOW){
		double x=intersectX(v,ymin);
		if(c1&BELOW){
			v[0]={x,ymin};
			c1=getRegionCode(v[0],xmin,ymin,xmax,ymax);
		}else{
			v[1]={x,ymin};
			c2=getRegionCode(v[1],xmin,ymin,xmax,ymax);
		}
	}
	//below
	if((c1^c2)&ABOVE){
		double x=intersectX(v,ymax);
		if(c1&ABOVE){
			v[0]={x,ymax};
			c1=getRegionCode(v[0],xmin,ymin,xmax,ymax);
		}else{
																																																																																																																	v[1]={x,ymax};
			c2=getRegionCode(v[1],xmin,ymin,xmax,ymax);
		}
	}
	//LEFT
	if((c1^c2)&LEFT){
		double y=intersectY(v,xmin);
		if(c1&LEFT){
			v[0]={xmin,y};
			c1=getRegionCode(v[0],xmin,ymin,xmax,ymax);
		}else{
			v[1]={xmin,y};
			c2=getRegionCode(v[1],xmin,ymin,xmax,ymax);
		}
	}
	//RIGHT
	if((c1^c2)&RIGHT){
		double y=intersectY(v,xmax);
		if(c1&RIGHT){
			v[0]={xmax,y};
			c1=getRegionCode(v[0],xmin,ymin,xmax,ymax);
		}else{
			v[1]={xmax,y};
			c2=getRegionCode(v[1],xmin,ymin,xmax,ymax);
		}
	}
	return v;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int xmin=40,ymin=40,xmax=100,ymax=80;
	vector< vector<Point> > L={{{30,65},{55,30}},
				   {{60,20},{110,90}},
				   {{60,100},{80,70}},
				   {{85,50},{120,75}}};
	for(vector<Point> v:L){
		rectangle(xmin,ymin,xmax,ymax);
		line(v[0].x,v[0].y,v[1].x,v[1].y);
		getchar();
		cleardevice();
		rectangle(xmin,ymin,xmax,ymax);
		vector<Point> p=clip(xmin,ymin,xmax,ymax,v);
		if(!p.empty())
			line(p[0].x,p[0].y,p[1].x,p[1].y);
		getchar();
		cleardevice();
	}
	closegraph();
	return 0;
}	

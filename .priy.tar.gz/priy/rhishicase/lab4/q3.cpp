#include"../lab3/geometry.cpp"
int mx,my;
void floodFill(int x,int y,int bgColor,int pColor){
	if(x<0||y<0||x>mx||y>my||getpixel(x,y)==bgColor||getpixel(x,y)==pColor)
		return;
	putpixel(x,y,pColor);
	delay(1);
	for(int i=-1;i<2;i++)
		for(int j=-1;j<2;j++)
			if(i==-j||i==j)
				continue;
			else
				floodFill(x+i,y+j,bgColor,pColor);
	return;
	
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	mx=getmaxx(),my=getmaxy();	
	vector<Point> p={{40,20},{70,30},{80,50},{50,40},{20,50}};
	drawPolygon(transform(p,translate(200,200)*scale(5,5)*translate(-40,-20)));
	floodFill(200,210,WHITE,RED);
	getchar();
	closegraph();
	return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
void MPT(){
	int x1=1,y1=1,x2=100,y2=100;
	//printf("Enter the coordinates of the two points between which line should be drawn\n");
//	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	int dx=x2-x1;
	int dy=y2-y1;
	double d;
	if(dy<dx)
		d=dy-(dx/2.0);
	else
		d=dx-(dy/2.0);

	putpixel(x1,y1,WHITE);
	int x=x1,y=y1;
	if(dy<dx)
		while(x<x2){
			x++;
			if(d<0)
				d+=dy;
			else{
				d+=(dy-dx);
				y++;
			}
			putpixel(x,y,WHITE);
		}
	else
		while(y<y2){
			y++;
			if(d<0)
				d+=dx;
			else{
				d+=dx-dy;
				x++;
			}
			putpixel(x,y,WHITE);
		}
			
	return ;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	MPT();
	
	int in = 0;

	while (in == 0) {
	    in = getchar();
	}

	closegraph();
	return 0;
} 

#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
void putcir(int x,int y,int p,int q){
	putpixel(p+x,q+y,WHITE);
	putpixel(p+x,q-y,WHITE);
	putpixel(p-x,q+y,WHITE);
	putpixel(p-x,q-y,WHITE);
	putpixel(p+y,q+x,WHITE);
	putpixel(p+y,q-x,WHITE);
	putpixel(p-y,q+x,WHITE);
	putpixel(p-y,q-x,WHITE);
	
}	
void MPC(){
	int xc=200,yc=200,r=100;
	int x=0,y=r;
	int d=3-2*r;
	while(x<=y){
		putcir(x,y,xc,yc);
		x++;
		if(d<0){
			d+=4*x+6;
		}
		else{
			y--;			
			d+=4*(x-y)+10;
		}
		delay(100);	
	}	
	return ;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	MPC();
	
	int in = 0;

	while (in == 0) {
	    in = getchar();
	}

	closegraph();
	return 0;
} 

#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
//#include<X11/Xlib.h>
void DDA(){
	int x1=1,y1=1,x2=100,y2=100;
	printf("Enter the coordinates of the two points between which line should be drawn\n");
//	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	int dx=x2-x1;
	int dy=y2-y1;
	int steps;
	if(abs(dx)>abs(dy))
		steps=abs(dx);
	else
		steps=abs(dy);
	double xinc=dx/((double)steps);
	double yinc=dy/((double)steps);
	double x=x1,y=y1;
	for(int i=0;i<steps;i++){
		putpixel((int)floor(x),(int)floor(y),WHITE);
		x+=xinc;
		y+=yinc;
		delay(100);
				
	}
	return ;
}
int main(){
	//XInitThreads();
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	DDA();
	
	int in = 0;

	while (in == 0) {
	    in = getchar();
	}

	closegraph();
	return 0;
} 

#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
void BRS(){
	int x1=1,y1=1,x2=100,y2=100;
	//printf("Enter the coordinates of the two points between which line should be drawn\n");
//	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	int dx=x2-x1;
	int dy=y2-y1;
	int p=2*dy-dx;
	putpixel(x1,y1,WHITE);
	int x=x1,y=y1;
	for(int i=1;i<dx;i++){
		if(p<0){
			x++;
			p+=2*dy;
		}else{
			p+=(2*dy-dx);
			x++;
			y++;
		}
		putpixel(x,y,WHITE);
		delay(100);
	}
	return ;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	BRS();
	
	int in = 0;

	while (in == 0) {
	    in = getchar();
	}

	closegraph();
	return 0;
} 

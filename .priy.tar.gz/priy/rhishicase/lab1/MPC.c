#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
void putpt(int x,int y,int xc,int yc){
	putpixel(x+xc,y+yc,WHITE);
	putpixel(y+xc,x+yc,WHITE);
}
void putcir(int x,int y,int xc,int yc){
	putpt(x,y,xc,yc);
	putpt(-x,y,xc,yc);
	putpt(x,-y,xc,yc);
	putpt(-x,-y,xc,yc);
}	
void MPC(){
	int xc=200,yc=200,r=100;
	int x=0,y=r;
	double p=1.25-r;
	putcir(x,y,xc,yc);
	while(x<y){
		if(p<0){
			x++;
			p+=2*x+1;
		}else{
			x++;
			y--;
			p+=2*x+1-2*y;
		}
		putcir(x,y,xc,yc);
		delay(100);
	}	
					
	return ;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	MPC();
	
	int in = 0;

	while (in == 0) {
	    in = getchar();
	}

	closegraph();
	return 0;
} 

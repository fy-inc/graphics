#include"geometry3D.cpp"

int red[513][513],green[513][513],blue[513][513];
double hue[513][513],sat[513][513],inten[513][513];

void RGBTOHSI(int i,int j){
	double r=red[i][j],g=green[i][j],b=blue[i][j];
	double th=acos(0.5*(r-g+r-b)/sqrt((r-g)*(r-g)+(r-b)*(g-b)));
	th*=180;
	th/=PI;
	if(b<=g)
		hue[i][j]=th;
	else
		hue[i][j]=360-th;
	sat[i][j]=1-3.0*min(min(r,g),b)/(r+g+b);
	inten[i][j]=(r+g+b)/3;
}
double toRad(double deg){
	return deg*PI/180;
}
void HSITORGB(int i,int j){
	double h=hue[i][j];
	double s=sat[i][j];
	double I=inten[i][j];
	if(h<120){
		red[i][j]=I*(1+s*cos(toRad(h))/(cos(toRad(60-h))));
		blue[i][j]=I*(1-s);
		green[i][j]=3*I-red[i][j]-blue[i][j];
	}else if(h<240){
		h-=120;
		red[i][j]=I*(1-s);
		green[i][j]=I*(1+s*cos(toRad(h))/(cos(toRad(60-h))));
		blue[i][j]=3*I-red[i][j]-green[i][j];
	}else{
		h-=240;	
		blue[i][j]=I*(1+s*cos(toRad(h))/(cos(toRad(60-h))));;
		green[i][j]=I*(1-s);
		red[i][j]=3*I-green[i][j]-blue[i][j];
	}

}	
void px(int x,int y,int r,int g,int b){
	red[y][x]=r;
	green[y][x]=g;
	blue[y][x]=b;
}
void DDA(Point p1,Point p2,int r,int g,int b){
	int x1=p1.x,y1=p1.y,x2=p2.x,y2=p2.y;
	int dx=x2-x1;
	int dy=y2-y1;
	int steps;
	if(abs(dx)>abs(dy))
		steps=abs(dx);
	else
		steps=abs(dy);
	double xinc=dx/((double)steps);
	double yinc=dy/((double)steps);
	double x=x1,y=y1;
	for(int i=0;i<steps;i++){
		px((int)floor(x),(int)floor(y),r,g,b);
		x+=xinc;
		y+=yinc;
				
	}
	return ;
}	
vector< vector<Point> > cubfac; 
vector<Point> vertices;
void fill(int x,int y,int r,int g,int b){
	if(x<1||y<1||x>512||y>512||red[y][x]||green[y][x]|blue[y][x])
		return;
	px(x,y,r,g,b);
	for(int i=-1;i<=1;i++)
		for(int j=-1;j<=1;j++)
			if(i!=j&&i!=-j)
				fill(x+i,y+j,r,g,b);
	
}
int main(){
	vector< vector<Point> > cubf={{{100,100,100},{200,100,100},{200,200,100},{100,200,100}},
				      {{100,100,100},{100+100/sqrt(2),100-100/sqrt(2),0},{200+100/sqrt(2),
					100-100/sqrt(2),0},{200,100,100}},
				      {{200,100,100},{200+100/sqrt(2),100-100/sqrt(2),0},
					{200+100/sqrt(2),200-100/sqrt(2),0},{200,200,100}}};
	//draw each edge
	for(vector<Point> poly:cubf)
		for(int i=0;i<4;i++)
			DDA(poly[i],poly[(i+1)%4],255,255,255);
	fill(150,150,255,20,40);
	cout<<"dd"<<endl;
	fill(150,90,220,20,40);
	cout<<"dd"<<endl;
	fill(210,150,200,20,40);
	for(vector<Point> poly:cubf)
		for(int i=0;i<4;i++)
			DDA(poly[i],poly[(i+1)%4],255,255,255);
	cout<<"dd"<<endl;	
	ofstream op("q1.ppm");
	op<<"P3# CREATOR: GIMP PNM Filter Version 1.1"<<endl;
	op<<"512 512"<<endl;
	op<<"255"<<endl;
	for(int i=1;i<=512;i++){
		for(int j=1;j<=512;j++)
			op<<red[i][j]<<" "<<green[i][j]<<" "<<blue[i][j]<<"\t";
		op<<endl;
	};
	op.close();
	cout<<"done"<<endl;		
				

}

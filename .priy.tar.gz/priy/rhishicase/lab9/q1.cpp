#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
double x1,x2,x3,x4;
double Y1,Y2,Y3,Y4;
double getx(double t){
	return x1*pow((1-t),3)+3*t*pow(1-t,2)*x2+3*t*t*(1-t)*x3+t*t*t*x4;
}
double gety(double t){
	return Y1*pow((1-t),3)+3*t*pow(1-t,2)*Y2+3*t*t*(1-t)*Y3+t*t*t*Y4;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	x1=100,Y1=50,x2=400,Y2=200,x3=60,Y3=0,x4=350,Y4=100;
	for(double t=0;t<=1;t+=0.001){
		putpixel(getx(t),gety(t),WHITE);
		delay(10);
	}
	getchar();
	closegraph();
}

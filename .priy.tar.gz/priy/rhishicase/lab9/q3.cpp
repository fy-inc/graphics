#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
double x1,x2,x3,x4,x5,x6;
double Y1,Y2,Y3,Y4,Y5,Y6;
double getx(double t){
	return x1*pow((1-t),5)+5*t*pow(1-t,4)*x2+10*t*t*pow((1-t),3)*x3+10*t*t*t*pow((1-t),2)*x4+5*pow(t,4)*(1-t)*x5+pow(t,5)*x6;
}
double gety(double t){
	return Y1*pow((1-t),5)+5*t*pow(1-t,4)*Y2+10*t*t*pow((1-t),3)*Y3+10*t*t*t*pow((1-t),2)*Y4+5*pow(t,4)*(1-t)*Y5+pow(t,5)*Y6;
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	x1=30,Y1=100,x6=230,Y6=100,x2=78,Y2=1000,x3=46,Y3=.175,x4=214,Y4=.175,x5=182,Y5=1000;
	putpixel(x2,Y2,RED);
	putpixel(x3,Y3,RED);
	putpixel(x4,Y4,RED);
	putpixel(x5,Y5,RED);
	for(double t=0;t<=1;t+=0.000001){
		putpixel(getx(t),gety(t),WHITE);
		//delay(10);
	}
	line(30,100,230,100);
	line(130,100,130,318);
	getchar();
	closegraph();
}

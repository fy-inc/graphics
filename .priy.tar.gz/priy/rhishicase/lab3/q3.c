#include "geometry.cpp"
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	vector<Point> v;
	v.push_back(Point(100,100));
	v.push_back(Point(100,200));
	v.push_back(Point(200,200));
	setcolor(RED);	
	drawPolygon(v);	
	setcolor(GREEN);
	Matrix mat=translate(50,50);
	delay(1000);
	mat=mat*rotate(-PI/4);
	delay(1000);
	mat=mat*translate(-50,-50);
	delay(1000);	
	transform(v,mat);
	drawPolygon(v);		
	while(!getchar());
	closegraph();
	return 0;
}

#include<vector>
#include<graphics.h>
#include<iostream>
using namespace std;
const double PI=acos(-1);
class Point{
public:
    double x,y;
    Point(){x=0;y=0;}
    Point(double a,double b){x=a,y=b;}
};
typedef vector< vector<double> > Matrix;
Matrix operator *(const Matrix &a,const Matrix & b){
    int n1=a.size(),n2=a[0].size(),n3=b[0].size();
    vector<double> d1(n3);
    Matrix ans(n1,d1);
    for(int k=0;k<n2;k++)
        for(int i=0;i<n1;i++)
            for(int j=0;j<n3;j++)
                ans[i][j]+=a[i][k]*b[k][j];
    return ans;
}
void drawPolygon(vector<Point> v){
    for(int i=0;i<v.size();i++)
        line(v[i].x,v[i].y,v[(i+1)%v.size()].x,v[(i+1)%v.size()].y);
}
Point transform(Point p, Matrix &mat){
    Matrix pt={{p.x},{p.y},{1}};
    Matrix result=mat*pt;
    return Point(result[0][0],result[1][0]);
}
vector<Point> transform(vector<Point> &v,Matrix mat){
    vector<Point> ans;
	for(int i=0;i<v.size();i++)
        ans.push_back(transform(v[i],mat));
    return ans;
}
Matrix rotate(double theta){
    Matrix ans={{cos(theta),    -sin(theta),    0},
                {sin(theta),    cos(theta),     0},
                {0,             0,              1}};
    return ans;
}
Matrix translate(double tx,double ty){
    Matrix ans={{1,0,tx},
                {0,1,ty},
                {0,0,1}};

    return ans;

}
Matrix shear(double hx,double hy){
    Matrix ans={{1,hx,0},
		{hy,1,0},
		{0,0,1}};
    return ans;
}
Matrix scale(double sx,double sy){
	Matrix ans={{sx,0,0},
		    {0,sy,0},
		    {0,0,1}};
	return ans;	
}


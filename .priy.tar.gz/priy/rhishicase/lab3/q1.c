#include<graphics.h>
#include<stdio.h>
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	setcolor(GREEN);	
	line(50,80,120,180);
	int sx=20,sy=10;
	setcolor(RED);
	line(50+sx,80+sy,120+sx,180+sy);
	getchar();
	closegraph();
	return 0;
	
}

#include "geometry.cpp"
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	vector<Point> v={{100,100},{200,100},{200,200},{100,200}};
	drawPolygon(v);
	vector<Point> cp=v;
	transform(v,scale(2,2));
	drawPolygon(v);
	getchar();
	cleardevice();
	v=cp;
	drawPolygon(v);
	transform(v,translate(100,100)*shear(0,2)*translate(-100,-100));
	drawPolygon(v);
	getchar();
	cleardevice();
	v=cp;
	drawPolygon(v);
	transform(v,translate(100,100)*shear(2,0)*translate(-100,-100));
	drawPolygon(v);
	getchar();
	closegraph();
	return 0;
}

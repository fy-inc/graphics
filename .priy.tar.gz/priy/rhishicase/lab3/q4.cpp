#include"geometry.cpp"
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	vector<Point> p;
	p.push_back(Point(100,100));
	p.push_back(Point(100,200));
	p.push_back(Point(200,200));
	int ht=getmaxy();
	int wd=getmaxx();
	line(wd/2,0,wd/2,ht);
	line(0,ht/2,wd,ht/2);
	transform(p,translate(wd/2,ht/2));
	drawPolygon(p);
	transform(p,translate(-wd/2,-ht/2));
	//reflection about x axis;
	for(int i=0;i<3;i++)
		p[i].y*=-1;
	transform(p,translate(wd/2,ht/2));
	drawPolygon(p);
	transform(p,translate(-wd/2,-ht/2));
	//reflection about y axis;
	for(int i=0;i<3;i++)
		p[i].y*=-1,p[i].x*=-1;
	transform(p,translate(wd/2,ht/2));
	drawPolygon(p);
	transform(p,translate(-wd/2,-ht/2));
	//reflection about x=y;
	for(int i=0;i<3;i++){
		p[i].x*=-1;
		swap(p[i].x,p[i].y);
	}
	transform(p,translate(wd/2,ht/2));
	drawPolygon(p);
	getchar();
	closegraph();
	return 0;
}

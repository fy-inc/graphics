#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;
double x1=10,Y1=10,x2=100,y2=100,slope1=500,slope2=-500;
double getX(double u){
	return (2*u*u*u-3*u*u+1)*x1+(-2*u*u*u+3*u*u)*x2+(u*u*u-2*u*u+u)+(u*u*u-u*u);
}
double getY(double u){
	return (2*u*u*u-3*u*u+1)*Y1+(-2*u*u*u+3*u*u)*y2+(u*u*u-2*u*u+u)*slope1+(u*u*u-u*u)*slope2;
}
void draw(){
double xl=0,yl=0;
	for(double u=0;u<=1;u+=0.000001){

		putpixel(round(getX(u)),round(getY(u)),WHITE);
		cout<<((getY(u)-yl)/0.000001)<<" "<<((getX(u)-xl)/0.000001)<<endl;
		xl=getX(u);
		yl=getY(u);
		//delay(1);
	}
}
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	draw();
	x1=100,Y1=100,x2=200,y2=200,slope1=-500,slope2=20;
	draw();	
	x1=200,Y1=200,slope1=20,x2=210,y2=40,slope2=0;
	draw();
	getchar();
	line(x1,Y1,x2,y2);
	getchar();
	closegraph();
	return 0;
}


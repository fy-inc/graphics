#include"../lab3/geometry.cpp"
int main(){
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	vector<Point> pl={{100,150},{200,250},{300,200}};
	vector<Point> cpl={{150,150},{150,200},{200,200},{200,150}};
	drawPolygon(pl);
	getchar();
	drawPolygon(cpl);
	getchar();
	closegraph();
	return 0;
}

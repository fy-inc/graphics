#include<stdio.h>
#include<graphics.h>
#include<math.h>
int main()
{
 int x[4], y[4];
    int i;
    for (i=0; i<4; i++)
		scanf ("%d %d",&x[i],&y[i]);
    int gd=DETECT,gm;
	initgraph(&gd,&gm,0);
      double t=0;
   double x1,y1;
     for(;t<1;t+=.005)
    {
      x1=pow(1-t,3)*x[0]+3*pow(1-t,2)*t*x[1]+3*(1-t)*t*t*x[2]+pow(t,3)*x[3];
      y1=pow(1-t,3)*y[0]+3*pow(1-t,2)*t*y[1]+3*(1-t)*t*t*y[2]+pow(t,3)*y[3];
      putpixel((int)x1,(int)y1,WHITE);
      delay(10);
    }
return 0;
}
/*

100 25
80 67
190 150
100 100

*/

#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
//dda
void dda(int x0,int y0,int x1,int y1)
{
  int dx,dy;
   dx=x1-x0;
   dy=y1-y0;
   int steps=(dx>dy)?dx:dy;
   float xinc=dx/(float(steps));
   float yinc=dy/(float(steps));
   int x=x0,y=y0;
   for(int i=0;i<steps;i++)
   {
     putpixel(x,y,WHITE);
   delay(1000);
   x+=xinc;
   y+=yinc;
   }
}
//bresenham
void bres(int x0,int y0,int x1,int y1)
{
  int dx,dy;
   dx=x1-x0;
   dy=y1-y0;
   int d=2*dy-dx;
   int x=x0,y=y0;
   putpixel(x,y,WHITE);
   delay(10);
   while(x<x1)
    {
    if(d<0)
       d+=2*dy;
    else
       d+=2*(dy-dx),y++;
     x++;
      putpixel(x,y,WHITE);
   delay(10);
    }
  }
//mid
void mid(int x0,int y0,int x1,int y1)
{
  int dx,dy;
   dx=x1-x0;
   dy=y1-y0;
  float d;
     if(dy<dx)
         d=dy-dx/2;
     else
         d=dx-dy/2;
  int x=x0,y=y0;
  if(dy<dx)
        while(x<x1)
        {
           putpixel(x,y,WHITE);
            delay(10);
            if(d<0)
              d+=dy;
            else
              d+=dy-dx,y++;
            x++;
        }
   else
       while(y<y1)
        {
           putpixel(x,y,WHITE);
            delay(10);
              if(d<0)
                 d+=dx;
              else
                 d+=dx-dy,x++;

           y++;
        }
 }



      
int main()
{
   int x0,y0,x1,y1;
   x0=50,y0=50,x1=250,y1=250;
   int gd=DETECT,gm;
   initgraph(&gd,&gm,NULL);
  // dda(x0,y0,x1,y1);
   //bres(x0,y0,x1,y1);
   mid(x0,y0,x1,y1);
   return 0;
}

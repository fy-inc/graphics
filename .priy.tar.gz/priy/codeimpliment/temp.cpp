#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
struct pt
{
  int x,y;
};
void translate(pt arr[],int n,int a,int b)
{
  for(int i=0;i<n;i++)
   {
     arr[i].x=arr[i].x + a;
     arr[i].y=arr[i].y + b;
   }
}
void rotate(pt arr[],int n ,double angle)
{
  for(int i=0;i<n;i++)
   {
     arr[i].x=(arr[i].x)*cos(angle) - (arr[i].y)*sin(angle);
     arr[i].y=(arr[i].x)*(sin(angle)) + (arr[i].y)*cos(angle);
   } 
}
void reflec(pt arr[],int n)
{
   for(int i=0;i<n;i++)
   {
     arr[i].x=arr[i].x;
     arr[i].y=-arr[i].y;
   }
}
   
int main()
{
  
   int m,c;
    cout<<"enter slope of line and cosntant  \n";
    cin>>m>>c;
    double angle;
    angle=(atan(m))*(180/(3.14));
    cout<<"angle is \n"<<angle<<"\n";
    int n;
   cout<<"sin is \n"<<sin(angle)<<"\n";
   cout<<"enter no of points in curve\n";
   cin>>n;
   pt point[n];
   cout<<"enter point s \n";
   for(int i=0;i<n;i++)
   {
     cin>>point[i].x>>point[i].y;
   }

int gd=DETECT,gm;
   initgraph(&gd,&gm,NULL);
   line(point[0].x,point[0].y,point[1].x,point[1].y);
    delay(1000);
    line(point[1].x,point[1].y,point[2].x,point[2].y);
    delay(1000);
    line(point[2].x,point[2].y,point[0].x,point[0].y);
    delay(1000);
   int X,Y;
    X=0;
    Y=c;
    translate(point,n,-X,-Y);
    rotate(point,n,-angle);
    reflec(point,n);
    rotate(point,n,+angle);
    translate(point,n,X,Y);
   line(point[0].x,point[0].y,point[1].x,point[1].y);
    delay(1000);
    line(point[1].x,point[1].y,point[2].x,point[2].y);
    delay(1000);
    line(point[2].x,point[2].y,point[0].x,point[0].y);
    delay(1000);
   
    return 0;
    
 
}

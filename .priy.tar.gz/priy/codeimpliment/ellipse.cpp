#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
void plot1(int x , int y,int c1,int c2)
{
   putpixel(x+c1,y+c2,1);delay(10);
   putpixel(-x+c1,y+c2,1);delay(10);
   putpixel(x+c1,-y+c2,1);delay(10);
   putpixel(-x+c1,-y+c2,1);delay(10);
}
void mid(int a,int b,int c1,int c2)
{
  int x=0,y=b;
   float b2=b*b,a2=a*a;
  float p1=b2+a2*(.25-b);
  plot1(x,y,c1,c2);
  while(b2*x<a2*y)
  {
     if(p1<0)
      p1+=b2*(2*x+3);
     else
      p1+=b2*(2*x+3)+ a2*(-2*y+2),y--;
     x++;
   plot1(x,y,c1,c2);delay(10);
 }
 float p2=b2*(x+.5)*(x+.5)+a2*(y-1)*(y-1)-a2*b2;
 while(y>0)
  {
   if(p2<0)
     p2+=b2*(2*x+2)+a2*(-2*y+3),x++;
   else
    p2+=a2*(-2*y+3);
   y--;
  plot1(x,y,c1,c2);delay(10);
  }
}
 
int main()
{
int a=20,b=10,c1=250,c2=250;
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
mid(a,b,c1,c2);
//bres(r,c1,c2);
return 0;
}
   

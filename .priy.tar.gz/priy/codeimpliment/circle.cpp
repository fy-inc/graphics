#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
void plot1(int x , int y,int c1,int c2)
{
   putpixel(x+c1,y+c2,1);delay(10);
   putpixel(-x+c1,y+c2,1);delay(10);
   putpixel(x+c1,-y+c2,1);delay(10);
   putpixel(-x+c1,-y+c2,1);delay(10);
   putpixel(y+c1,x+c2,1);delay(10);
   putpixel(-y+c1,x+c2,1);delay(10);
   putpixel(y+c1,-x+c2,1);delay(10);
   putpixel(-y+c1,-x+c2,1);delay(10);
}
void mid(int r,int c1,int c2)
{
   int x=0,y=r,p=1-r;
   plot1(x,y,c1,c2);   
   while(x<y)
   {
      if(p<0)
         p+=2*x+3;
      else
         p+=2*(x-y)+3,y--;
      x++;
   plot1(x,y,c1,c2);
   }
}
void bres(int r,int c1,int c2)
{
  int x=0,y=r,p=3-2*r;
   plot1(x,y,c1,c2); 
    while(x<y)
   {
      if(p<0)
         p+=4*x+6;
      else
         p+=4*(x-y)+6,y--;
      x++;
   plot1(x,y,c1,c2);
   }
}
int main()
{
int r=20,c1=250,c2=250;
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
//mid(r,c1,c2);
bres(r,c1,c2);
return 0;
}
   

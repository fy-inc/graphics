#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
void draw(int s[],int e[],int t[])
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,NULL);
    line(s[0],s[1],e[0],e[1]);
    delay(1000);
    int s0=s[0]+t[0];
    int s1=s[1]+t[1];
    int e0=e[0]+t[0];
    int e1=e[1]+t[1];
    line(s0,s1,e0,e1);
    delay(1000);
    closegraph();

}
int main()
{
    int s[2],e[2],t[2];
    s[0]=5;
    s[1]=8;
    e[0]=120;
    e[1]=180;
    t[0]=100;
    t[1]=200;
    draw(s,e,t);
}
#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;
void fill1(int x,int y,int old,int newc)
{
  if(getpixel(x,y)==old)
     {
        putpixel(x,y,newc);
        fill1(x+1,y,old,newc);
        fill1(x,y+1,old,newc);
        fill1(x-1,y,old,newc);
        fill1(x,y-1,old,newc);
     }
}
int main()
{
 int n;
cin>>n;
int arrx[n],arry[n];
for(int i=0;i<n;i++)
   cin>>arrx[i]>>arry[i];
int a,b;
cin>>a>>b;
int gd=DETECT,gm;
	initgraph(&gd,&gm,0);
int c=getpixel(a,b);

for(int i=0;i<n;i++)
{
   line(arrx[i%n],arry[i%n],arrx[(i+1)%n],arry[(i+1)%n]);
  delay(100);
}
fill1(a,b,c,WHITE);
char ch;
cin>>ch;
return 0;
}


#include<bits/stdc++.h>
#include<graphics.h>
int gd=DETECT,gm=0;

int main(){
	int x1,y1,x2,y2,m1,m2;
	scanf("%d %d",&x1,&y1);
	scanf("%d %d",&x2,&y2);
	scanf("%d %d",&m1,&m2);
	double x,y;	
	double t=0.0;
	initgraph(&gd,&gm,0);
	for(;t<1;t+=0.001)
       {
         x=(2*pow(t,3)-3*pow(t,2)+1)*x1+(-2*pow(t,3)+3*pow(t,2))*x2+(pow(t,3) - 2*pow(t,2)+1)*m1+(pow(t,3)-pow(t,2))*m2;
          y=(2*pow(t,3)-3*pow(t,2)+1)*y1+(-2*pow(t,3)+3*pow(t,2))*y2+(pow(t,3) - 2*pow(t,2)+1)*m1+(pow(t,3)-pow(t,2))*m2;
	 putpixel(x,y,1);
        delay(10);
       }
 return 0;
	//closegraph();
}
/*
	
10 10
200 100
300 -1000

*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <graphics.h>

void MPTE(int a, int b, int x0, int y0)
{
	int x = 0, y = b;
	double pr1 = b*b + a*a/(double)4 - a*a*b;
	putpixel(x + x0, y + y0, WHITE);
	putpixel(-x + x0, -y + y0, WHITE);
	while(2*b*b*x <= 2*a*a*y)
	{
		if(pr1 < 0)
		{
			x++;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			pr1 += 2*b*b*x + b*b;
		}
		else
		{
			x++;
			y--;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			pr1 += 2*b*b*x - 2*a*a*y + b*b;
		}
	}
	double pr2 = b*b*(x + 1/(double)2)*(x + 1/(double)2) + a*a*(y - 1)*(y - 1) - a*a*b*b;
	while(y >= 0)
	{
		if(pr2 > 0)
		{
			y--;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			pr2 += a*a - 2*a*a*y;
		}
		else
		{
			y--;
			x++;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			pr2 += 2*b*b*x - 2*a*a*y + a*a;
		}
	}
	return;
}

void main()
{
	//INPUT 50 25 200 200
	int gd = DETECT, gm = 0, a,b,x0,y0;
	scanf("%d %d %d %d", &a, &b, &x0, &y0);
	initgraph(&gd, &gm, NULL);
	MPTE(a, b, x0, y0);
	delay(10000);
	return;
}

#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

int TRANS(int c, int sh)
{
	return (c + sh);
}	

int main(void)
{
	//INPUT 1 1 67 56 70 68 
	int gd = DETECT, gm = 0, x1, y1, x2, y2, xt, yt;
	scanf("%d %d %d %d %d %d", &x1, &y1, &x2, &y2, &xt, &yt);
	initgraph(&gd, &gm, NULL);
	line(x1, y1, x2, y2);
	x1 = TRANS(x1, xt);
	y1 = TRANS(y1, yt);
	x2 = TRANS(x2, xt);
	y2 = TRANS(y2, yt);
	line(x1, y1, x2, y2);
	delay(10000);
	return 0;
}	

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <graphics.h>

void MIDPT(int x1, int y1, int x2, int y2)
{
	double dx = x2 - x1, dy = y2 - y1;
	double D = 0;
	if(dy < dx)
	D = dy - (dx/(double)2);
	else D = dx - (dy/(double)2);
	double x = x1, y = y1;
	putpixel(x, y, WHITE);
	if(dy < dx)
	{
		while(x < x2)
		{
			x++;
			if(D < 0)
			D += dy;
			else
			{	
				D += dy - dx;
				y++;
			}
			putpixel(x, y, WHITE);
		}
	}
	else
	{
		while(y < y2)
		{
			y++;
			if(D < 0)
			D += dx;
			else
			{
				D += dx - dy;
				x++;
			}
			putpixel(x, y, WHITE);
		}
	}
	return;
}	

void main()
{
	//INPUT 12 34 56 109 
	int gd = DETECT, gm = 0, x1, y1, x2, y2;
	scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
	initgraph(&gd, &gm, NULL);
	MIDPT(x1, y1, x2, y2);
	delay(10000);
	return;
}	

#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

int xpt[101], ypt[101];

int main(void)
{
	int gd = DETECT, gm = 0;
	int n;
	scanf("%d", &n);
	for(int i=0;i<n;i++)
	scanf("%d %d", xpt + i, ypt + i);
	initgraph(&gd, &gm, NULL);
	for(int i=0;i<n-1;i++)
	line(xpt[i], ypt[i], xpt[i+1], ypt[i+1]);
	line(xpt[n-1], ypt[n-1], xpt[0], ypt[0]);
	for(int i=0;i<n-1;i++)
	line(-xpt[i] + 300, ypt[i], -xpt[i+1] + 300, ypt[i+1]);
	line(-xpt[n-1] + 300, ypt[n-1], -xpt[0] + 300, ypt[0]);
	for(int i=0;i<n-1;i++)
	line(xpt[i], -ypt[i] + 300, xpt[i+1], -ypt[i+1] + 300);
	line(xpt[n-1], -ypt[n-1] + 300, xpt[0], -ypt[0] + 300);
	for(int i=0;i<n-1;i++)
	line(ypt[i], xpt[i], ypt[i+1], xpt[i+1]);
	line(ypt[n-1], xpt[n-1], ypt[0], xpt[0]);
	delay(10000);
	return 0;
}			

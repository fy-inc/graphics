#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <graphics.h>

void MPTC(int r, int x0, int y0)
{
	int x = 0, y = r;
	putpixel(x + x0, y + y0, WHITE);
	putpixel(-x + x0, -y + y0, WHITE);
	putpixel(y + x0, x + y0, WHITE);
	putpixel(-y + x0, -x + y0, WHITE);
	double p = (double)5/(double)4 - r;
	while(x <= y)
	{
		if(p < 0)
		{
			x++;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(y + x0, x + y0, WHITE);
			putpixel(-y + x0, -x + y0, WHITE);
			putpixel(y + x0, -x + y0, WHITE);
			putpixel(-y + x0, x + y0, WHITE);
			p += 2*x + 1;
		}
		else
		{
			x++;
			y--;
			putpixel(x + x0, y + y0, WHITE);
			putpixel(-x + x0, -y + y0, WHITE);
			putpixel(x + x0, -y + y0, WHITE);
			putpixel(-x + x0, y + y0, WHITE);
			putpixel(y + x0, x + y0, WHITE);
			putpixel(-y + x0, -x + y0, WHITE);
			putpixel(y + x0, -x + y0, WHITE);
			putpixel(-y + x0, x + y0, WHITE);
			p += 2*(x - y) + 1;
		}
	}
	return;
}	

void main()
{
	//INPUT 45 308 205
	int gd = DETECT, gm = 0, r, x0, y0;
	scanf("%d %d %d", &r, &x0, &y0);
	initgraph(&gd, &gm, NULL);
	MPTC(r, x0, y0);
	delay(10000);
	return;
}	

#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>
int gd = DETECT, gm=0;
void bezier (int x[4], int y[4]){
    int i;
    double t;
    for (t = 0.0; t < 1.0; t += 0.0005){
		double xt = pow(1-t,3)*x[0]+3*t*pow(1-t,2)*x[1]+3*pow(t,2)*(1-t)*x[2]+pow(t,3)*x[3];
		double yt = pow(1-t,3)*y[0]+3*t*pow(1-t,2)*y[1]+3*pow(t,2)*(1-t)*y[2]+pow(t,3)*y[3];
		putpixel (xt, yt, WHITE);

	}
 	for (i=0; i<4; i++)
		putpixel (x[i], y[i], YELLOW);
}
void bezier1(int x1,int y1, int x2, int y2, int x3, int y3, int x4, int y4)
{
        putpixel(x1,y1,RED);
        putpixel(x2,y2,RED);
        putpixel(x3,y3,RED);
        putpixel(x4,y4,RED);
        for(float t=0;t<1;t+=0.001)
        {
                int x=(1-t)*(1-t)*(1-t)*x1 +3*t*(1-t)*(1-t)*x2 +3*t*t*(1-t)*x3+ t*t*t*x4;
                int y=(1-t)*(1-t)*(1-t)*y1 +3*t*(1-t)*(1-t)*y2 +3*t*t*(1-t)*y3+ t*t*t*y4;
                putpixel(x,y,1);
                delay(10);
        }
}
void main(){
    int x[4], y[4];
    int i;
    for (i=0; i<4; i++)
		scanf ("%d %d",&x[i],&y[i]);
	initgraph(&gd,&gm,0);
    bezier1(x[0],y[0],x[1],y[1],x[2],y[2],x[3],y[3]);
	delay(1000);
	closegraph();
}
/*

100 25
80 67
190 150
100 100

*/

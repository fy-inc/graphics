#include<graphics.h>
#include<stdio.h>

int gd=DETECT,gm=0;

void box(int x,int y,int w,int h,int c){
	setcolor(c);
	int i,j;
	for(i=x;i<=x+w;i++)
		for(j=y;j<=y+h;j++)
			putpixel(i,j,c);
}

void wheels(int x,int y,int r,int c){
	setcolor(c);
	circle(x,y,r);
	ffill(0,0,x,y,r,r,c);
}

void ffill(int x,int y,int xc,int yc,int a,int b,int c){
	if( (b*b*x*x + a*a*y*y - a*a*b*b >= 0) || getpixel(x+xc,y+yc)==c)
		return;
	putpixel(x+xc,y+yc,c);
	ffill(x-1,y,xc,yc,a,b,c);
	ffill(x+1,y,xc,yc,a,b,c);
	ffill(x,y+1,xc,yc,a,b,c);
	ffill(x,y-1,xc,yc,a,b,c);

}
void car(int x1,int y1,int w1,int h1,
	int x2,int y2,int w2,int h2,
	int c1,
	int x3,int y3,int r1,
	int x4,int y4,int r2,
	int c2){
	box(x1,y1,w1,h1,c1);
	box(x2,y2,w2,h2,c1);
	wheels(x3,y3,r1,c2);
	wheels(x4,y4,r2,c2);
}


void main(){
	initgraph(&gd,&gm,0);

	int t=0;
	int c=0;
	while(c<30){
		car(50+t,275,100,125,
		150+t,350,50,50,
		(c%10)+1,
		75+t,410,10,
		175+t,410,10,
		(c%10)+2);
		delay(100);
		setcolor(0);
		cleardevice();
		t+=20;
		c++;
		if(t+200>=640)
			t=0;
	}

	closegraph();
}
